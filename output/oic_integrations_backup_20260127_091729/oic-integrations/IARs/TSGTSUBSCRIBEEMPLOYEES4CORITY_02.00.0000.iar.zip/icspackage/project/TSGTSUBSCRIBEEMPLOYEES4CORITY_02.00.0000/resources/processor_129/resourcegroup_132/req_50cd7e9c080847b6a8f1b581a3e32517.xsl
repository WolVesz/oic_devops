<xsl:stylesheet version="2.0" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:tgrr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types" xmlns:tgr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:empr="http://xmlns.oracle.com/cloud/adapter/REST/PublishEmployees_REQUEST/types" xmlns:emp="http://xmlns.oracle.com/cloud/adapter/REST/PublishEmployees/types" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:ns1="http://xml.oracle.com/adapters/extension" xmlns:insQr="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:orajs0="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath86288" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfig/types" xmlns:cfgr="http://xmlns.oracle.com/cloud/adapter/REST/GetConfig_REQUEST/types" exclude-result-prefixes=" oraext xsd xp20 ora oracle-xsl-mapper xsi fn xsl ignore01" ignore01:ignorexmlids="true">
				
        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_110/outbound_111/resourcegroup_112/EVENT_TSGTPUBLISHEMPLO_SER_2247_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_134/resourcegroup_135/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_117/inbound_118/resourcegroup_119/PublishEmployees_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/PublishEmployees_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>

	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	<xsl:param name="self"/>

	<xsl:variable name="today" select="concat(fn:year-from-dateTime (fn:current-dateTime ()),'-',fn:month-from-dateTime (fn:current-dateTime()),'-',fn:day-from-dateTime (fn:current-dateTime ()))"/>

    <xsl:template name="changeNamespace">
        <xsl:param name="nodes"/>

        <xsl:for-each select="$nodes">
            <xsl:choose>
                <xsl:when test="count(child::*)>0">
                    <xsl:element name="emp:{local-name()}">
                        <xsl:call-template name="changeNamespace">
                            <xsl:with-param name="nodes" select="./child::*"/>
                        </xsl:call-template>
                    </xsl:element>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:element name="emp:{local-name()}">
                        <xsl:if test="@xsi:nil='true'">
                            <xsl:attribute name="xsi:nil">true</xsl:attribute>
                        </xsl:if>

                        <xsl:value-of select="."/>
                    </xsl:element>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:for-each>
    </xsl:template>
	
	<xsl:template match="/tgrr:execute">
	
		<empr:execute>
			<emp:request-wrapper>
				<emp:EmployeesBatch>
					<emp:BatchID>
						<xsl:value-of select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:BatchID"/>
					</emp:BatchID>
					<emp:DateTime>
						<xsl:value-of select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:DateTime"/>
					</emp:DateTime>
					<xsl:for-each-group select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:Employees" group-by="tgr:PersonNumber">
						<emp:Employees>
							<xsl:choose>
								<xsl:when test="count(fn:current-group()[tgr:WorkerType='EMP' and tgr:EffectiveDate &lt;= string($today)]) > 0">
									<xsl:for-each select="fn:current-group()[tgr:WorkerType='EMP'][1]/child::*">
										<xsl:call-template name="changeNamespace">
											<xsl:with-param name="nodes" select="."/>
										</xsl:call-template>
									</xsl:for-each>
									<xsl:for-each select="fn:current-group()[tgr:WorkerType='EMP' and tgr:EffectiveDate &lt;= string($today)]">
										<xsl:for-each select="tgr:ChangedAttributes">
										<emp:ChangedAttributes>
											<emp:AttributeName>
												<xsl:value-of select="tgr:AttributeName"/>
											</emp:AttributeName>
											<emp:NewValue>
												<xsl:value-of select="tgr:NewValue"/>
											</emp:NewValue>
											<emp:OldValue>
												<xsl:value-of select="tgr:OldValue"/>
											</emp:OldValue>
										</emp:ChangedAttributes>
										</xsl:for-each>
									</xsl:for-each>
								</xsl:when>
							</xsl:choose>
						</emp:Employees>
					</xsl:for-each-group>
					<xsl:call-template name="changeNamespace">
						<xsl:with-param name="nodes" select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:Interface"/>
					</xsl:call-template>
					<xsl:call-template name="changeNamespace">
						<xsl:with-param name="nodes" select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:Attribute1"/>
					</xsl:call-template>
					<xsl:call-template name="changeNamespace">
						<xsl:with-param name="nodes" select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:Attribute2"/>
					</xsl:call-template>
					<xsl:call-template name="changeNamespace">
						<xsl:with-param name="nodes" select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:Attribute3"/>
					</xsl:call-template>
					<xsl:call-template name="changeNamespace">
						<xsl:with-param name="nodes" select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:Attribute4"/>
					</xsl:call-template>
					<xsl:call-template name="changeNamespace">
						<xsl:with-param name="nodes" select="tgr:request-wrapper/tgr:EmployeesBatch/tgr:Attribute5"/>
					</xsl:call-template>
				</emp:EmployeesBatch>
			</emp:request-wrapper>
		</empr:execute>
	</xsl:template>
</xsl:stylesheet>