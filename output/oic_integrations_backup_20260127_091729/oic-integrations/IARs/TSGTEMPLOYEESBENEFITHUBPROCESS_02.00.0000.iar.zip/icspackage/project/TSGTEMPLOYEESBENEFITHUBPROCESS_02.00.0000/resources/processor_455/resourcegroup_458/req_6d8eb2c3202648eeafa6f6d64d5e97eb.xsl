<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:cpr="http://xmlns.oracle.com/cloud/adapter/ftp/CopyFile_REQUEST/types" xmlns:ot="http://xml.oracle.com/types" xmlns:cp="http://xmlns.oracle.com/cloud/ics/file/v1/types" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" exclude-result-prefixes=" nssrcmpr ns7 oraext plnk xsd xp20 ora oracle-xsl-mapper nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">

	<oracle-xsl-mapper:schema>
		<!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
		<oracle-xsl-mapper:mapSources>
			<oracle-xsl-mapper:source type="WSDL">
				<oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/Trigger_REQUEST.wsdl"/>
				<oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/Trigger_REQUEST/types"/>
			</oracle-xsl-mapper:source>
			<oracle-xsl-mapper:source type="WSDL">
				<oracle-xsl-mapper:schema location="../../application_47/inbound_48/resourcegroup_49/GetConfigs_REQUEST.wsdl"/>
				<oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
				<oracle-xsl-mapper:param name="Configs"/>
			</oracle-xsl-mapper:source>
			<oracle-xsl-mapper:source type="XSD">
				<oracle-xsl-mapper:schema location="../../processor_64/resourcegroup_65/ICSIntegrationMetadata.xsd"/>
				<oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
				<oracle-xsl-mapper:param name="self"/>
			</oracle-xsl-mapper:source>
		</oracle-xsl-mapper:mapSources>
		<oracle-xsl-mapper:mapTargets>
			<oracle-xsl-mapper:target type="WSDL">
				<oracle-xsl-mapper:schema location="../../application_445/inbound_446/resourcegroup_447/CopyFile_REQUEST.wsdl"/>
				<oracle-xsl-mapper:rootElement name="WriteFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/CopyFile_REQUEST/types"/>
			</oracle-xsl-mapper:target>
		</oracle-xsl-mapper:mapTargets>
	</oracle-xsl-mapper:schema>

	<xsl:param name="DownloadFileReference"/>
	<xsl:param name="Configs"/>
	<xsl:param name="DocumentID"/>
	<xsl:param name="Now"/>
	<xsl:param name="foundExtract"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:variable name="filename">
		<xsl:choose>
			<xsl:when test="contains($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DetinationFileName']/cfg:Value,'mmddyyyy')">
				<xsl:value-of select="concat(substring-before($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DetinationFileName']/cfg:Value,'mmddyyyy'),xp20:format-dateTime(fn:current-dateTime(), '[M01][D01][Y0001]'),substring-after($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DetinationFileName']/cfg:Value,'mmddyyyy'))"/>
			</xsl:when>
			<xsl:otherwise>
				<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DetinationFileName']/cfg:Value"/>
			</xsl:otherwise>
		</xsl:choose>
	</xsl:variable>
		
	<xsl:template match="/">
		<cpr:WriteFile>
			<cpr:OutboundFTPHeaderType>
				<ot:fileName>
					<xsl:value-of select="string($filename)"/>
				</ot:fileName>
				<ot:directory>
					<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DetinationFolder']/cfg:Value"/>
				</ot:directory>
			</cpr:OutboundFTPHeaderType>
			<cp:ICSFile>
				<cp:FileReference>
					<xsl:value-of select="$DownloadFileReference"/>
				</cp:FileReference>
			</cp:ICSFile>
		</cpr:WriteFile>
	</xsl:template>
</xsl:stylesheet>