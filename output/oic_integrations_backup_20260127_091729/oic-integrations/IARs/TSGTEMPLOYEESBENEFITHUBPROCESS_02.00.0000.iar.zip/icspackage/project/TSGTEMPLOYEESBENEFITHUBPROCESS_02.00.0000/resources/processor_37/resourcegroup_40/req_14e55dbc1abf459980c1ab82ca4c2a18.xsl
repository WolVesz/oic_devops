<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:fa="http://xmlns.oracle.com/cloud/adapter/hcm/SubmitExtract_REQUEST/types" xmlns:fac="http://xmlns.oracle.com/apps/hcm/processFlows/core/flowControllerService/" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" exclude-result-prefixes=" nssrcmpr ns1 nssrcdfl oraext xsd xp20 ora oracle-xsl-mapper xsi fn xsl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/Trigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/Trigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_47/inbound_48/resourcegroup_49/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_64/resourcegroup_65/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_25/inbound_26/resourcegroup_27/SubmitExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="submitAndGetFlowInstanceId" namespace="http://xmlns.oracle.com/cloud/adapter/hcm/SubmitExtract_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>

	<xsl:param name="Configs"/>
	<xsl:param name="DocumentID"/>
	<xsl:param name="DownloadFileReference"/>
	<xsl:param name="Now"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>

	<xsl:template match="/">
		<fa:submitAndGetFlowInstanceId>
			<fa:flowName>
				<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='ExtractName']/cfg:Value"/>
			</fa:flowName>
			<fa:parameterValues>
				<fac:ParameterName>Changes Only</fac:ParameterName>
				<fac:ParameterValue>No</fac:ParameterValue>
			</fa:parameterValues>
			<fa:parameterValues>
				<fac:ParameterName>Effective Date</fac:ParameterName>
				<fac:ParameterValue>
					<xsl:value-of select="xp20:format-dateTime(fn:current-dateTime(),'[Y0001]-[M01]-[D01]')"/>
				</fac:ParameterValue>
			</fa:parameterValues>

			<fa:flowInstanceName>
				<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='ExtractName']/cfg:Value,'-',xp20:format-dateTime($Now,'[Y0001][M01][D01][H01][m01][s01]'))"/>
			</fa:flowInstanceName>
			<fa:legislativeDataGroupName>
				<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='LegislativeDG']/cfg:Value"/>
			</fa:legislativeDataGroupName>
			<fa:recurringFlag>false</fa:recurringFlag>

		</fa:submitAndGetFlowInstanceId>
	</xsl:template>

</xsl:stylesheet>