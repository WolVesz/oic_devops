<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:segr="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types" xmlns:seg="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/WriteFile" xmlns:tgtr="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadExtractFile_REQUEST/types" xmlns:tgt="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadExtractFile" xmlns:rp="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadParameters" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" exclude-result-prefixes=" nssrcmpr ns1 oraext plnk xsd xp20 ora oracle-xsl-mapper nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/Trigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/Trigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_50/inbound_51/resourcegroup_52/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_92/inbound_93/resourcegroup_94/DownloadFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="DownloadFileToICSResponse" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/DownloadFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="DownloadFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_92/inbound_93/resourcegroup_94/DownloadFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="DownloadFileToICS" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/DownloadFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="DownloadFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_107/resourcegroup_108/ReadExtractFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadExtractFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtractFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_507/resourcegroup_508/ReadParameters_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="DATA_DS" namespace="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadParameters"/>
                          <oracle-xsl-mapper:param name="parameters"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_1/resourcegroup_2/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_117/resourcegroup_118/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="DownloadFile"/>
	<xsl:param name="DownloadFile_REQUEST"/>
	<xsl:param name="ReadExtractFile"/>
	<xsl:param name="index"/>
	<xsl:param name="parameters"/>
	<xsl:param name="round"/>
	<xsl:param name="self"/>
	<xsl:param name="size"/>
	<xsl:param name="total"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>

    <xsl:template name="changeNamespace">
        <xsl:param name="nodes"/>

        <xsl:for-each select="$nodes">
            <xsl:choose>
                <xsl:when test="count(child::*)>0">
                    <xsl:element name="seg:{local-name()}">
                        <xsl:call-template name="changeNamespace">
                            <xsl:with-param name="nodes" select="./child::*"/>
                        </xsl:call-template>
                    </xsl:element>
                </xsl:when>
                <xsl:otherwise>
                    <xsl:element name="seg:{local-name()}">
                        <xsl:if test="@xsi:nil='true'">
                            <xsl:attribute name="xsi:nil">true</xsl:attribute>
                        </xsl:if>

                        <xsl:value-of select="."/>
                    </xsl:element>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:for-each>
    </xsl:template>
	
	<xsl:template match="/">
		<segr:Write>
			<seg:DATA_DS>
				<seg:G_1>
					<seg:G_2>
						<seg:FILE_FRAGMENT>
							<seg:Employee_Feed_V2>
								<xsl:call-template name="changeNamespace">
									<xsl:with-param name="nodes" select="$parameters/rp:DATA_DS/rp:G_1/rp:G_2/rp:FILE_FRAGMENT/rp:Employee_Feed_V2/rp:parameters"/>
								</xsl:call-template>

								<xsl:for-each select="$ReadExtractFile/tgtr:ReadResponse/tgt:DATA_DS/tgt:G_1/tgt:G_2/tgt:FILE_FRAGMENT/tgt:Employee_Feed_V2/tgt:Person">
									<xsl:if test="position() > (number($round) * number($size)) and position() &lt;= ((number($round) + 1) * number($size))">
										<xsl:call-template name="changeNamespace">
											<xsl:with-param name="nodes" select="."/>
										</xsl:call-template>
									</xsl:if>
								</xsl:for-each>
							</seg:Employee_Feed_V2>
						</seg:FILE_FRAGMENT>
					</seg:G_2>
				</seg:G_1>
			</seg:DATA_DS>
		</segr:Write>
	</xsl:template>
</xsl:stylesheet>