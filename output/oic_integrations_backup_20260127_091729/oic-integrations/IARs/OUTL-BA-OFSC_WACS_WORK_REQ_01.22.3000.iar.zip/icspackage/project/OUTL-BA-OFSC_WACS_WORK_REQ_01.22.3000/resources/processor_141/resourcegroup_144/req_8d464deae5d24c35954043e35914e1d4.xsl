<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xml:id="id_1" xmlns:ns1="http://xmlns.oracle.com/cloud/adapter/oracleutilities/createWorkRequest_REQUEST" xmlns:nssrcmpr="http://xmlns.oracle.com/cloud/adapter/ofsccloudadapter/receiveOFSCRequest_REQUEST/types" xmlns:ns5="http://xmlns.oracle.com/cloud/adapter/ofsccloudadapter/receiveOFSCRequest_REQUEST" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:wsp="http://www.w3.org/ns/ws-policy" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:nstrgmpr="http://xmlns.oracle.com/cloud/adapter/oracleutilities/createWorkRequest_REQUEST/types" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:wssutil="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:tns="http://ouaf.oracle.com/webservices/w1/W1-CreMoblWR" xmlns:ouaf="http://ouaf.oracle.com/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" exclude-result-prefixes=" nssrcmpr ns5 oraext xsd xp20 ora oracle-xsl-mapper xsi fn xsl ignore01" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" ignore01:ignorexmlids="true" xmlns:nsmpr0="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:xml="http://www.w3.org/XML/1998/namespace" xmlns:orajs1="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1635443809" xmlns:orajs11="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1667070767" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.dvm.DVMFunctions" xmlns:orajs14="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath948039040" xmlns:ns22="http://xmlns.oracle.com/cloud/adapter/inventoryDetails" xmlns:ns24="http://xmlns.oracle.com/cloud/adapter/activityDetails" xmlns:orajs4="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1681625448" xmlns:orajs0="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath56919032" xmlns:orajs7="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath123170385" xmlns:ns23="http://xml.oracle.com/adapters/extension" xmlns:ns26="http://xmlns.oracle.com/cloud/adapter/requestChanges" xmlns:orajs2="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1396154174" xmlns:orajs10="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1429540732" xmlns:orajs3="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1596616741" xmlns:ns25="http://xmlns.oracle.com/cloud/adapter/requestDetails" xmlns:orajs15="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath86288" xmlns:ns2="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:orajs12="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath877648652" xmlns:orajs8="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath761874789" xmlns:orajs13="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1673207123" xmlns:ns0="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:orajs5="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1634410945" xmlns:orajs9="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath673895125" xmlns:ns27="http://xmlns.oracle.com/cloud/adapter" xmlns:orajs6="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1468259163" xmlns:plnk="http://schemas.xmlsoap.org/ws/2003/05/partner-link/" xmlns:ns48="http://xmlns.oracle.com/procmon" xmlns:ns49="http://xmlns.oracle.com/ics/tracking/ics_tracking_context.xsd" xmlns:ns3="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1693831523" xmlns:ns4="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1327743971">
   <oracle-xsl-mapper:schema xml:id="id_2">
      <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
      <oracle-xsl-mapper:mapSources xml:id="id_3">
         <oracle-xsl-mapper:source type="WSDL" xml:id="id_4">
            <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/receiveOFSCRequest_REQUEST.wsdl" xml:id="id_5"/>
            <oracle-xsl-mapper:rootElement name="notify_POST" namespace="http://xmlns.oracle.com/cloud/adapter/ofsccloudadapter/receiveOFSCRequest_REQUEST/types" xml:id="id_6"/>
         </oracle-xsl-mapper:source>
      </oracle-xsl-mapper:mapSources>
      <oracle-xsl-mapper:mapTargets xml:id="id_7">
         <oracle-xsl-mapper:target type="WSDL" xml:id="id_8">
            <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/createWorkRequest_REQUEST.wsdl" xml:id="id_9"/>
            <oracle-xsl-mapper:rootElement name="W1-CreMoblWR" namespace="http://xmlns.oracle.com/cloud/adapter/oracleutilities/createWorkRequest_REQUEST/types" xml:id="id_10"/>
         </oracle-xsl-mapper:target>
      </oracle-xsl-mapper:mapTargets>
      <!--GENERATED BY ORACLE XSL MAPPER 12.1.2.0.0-->
   </oracle-xsl-mapper:schema>
   <!--User Editing allowed BELOW this line - DO NOT DELETE THIS LINE-->
   <xsl:param name="userIDVar" xml:id="id_92"/>
   <xsl:param name="defaultUser" xml:id="id_107"/>
   <xsl:template match="/" xml:id="id_11">
      <nstrgmpr:W1-CreMoblWR xml:id="id_12">
         <tns:W1-CreMoblWR xml:id="id_21">
            <tns:input xml:id="id_22">
               <tns:followUpActivityId xml:id="id_41">
                  <xsl:value-of xml:id="id_42" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_related_appt_number1"/>
               </tns:followUpActivityId>
               <tns:nodeId xml:id="id_23">
                  <xsl:value-of xml:id="id_24" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_asset_node_id1"/>
               </tns:nodeId>
               <tns:assetId xml:id="id_25">
                  <xsl:value-of xml:id="id_26" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_asset_id1"/>
               </tns:assetId>
               <tns:description xml:id="id_39">
                  <xsl:value-of xml:id="id_43" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_activity_desc1"/>
               </tns:description>
               <tns:longDescription xml:id="id_37">
                  <xsl:value-of xml:id="id_38" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_activity_long_desc1"/>
               </tns:longDescription>
               <tns:requiredByDate xml:id="id_65" xsi:nil="{'true'}">
                  <xsl:value-of xml:id="id_74" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_required_by_date1"/>
               </tns:requiredByDate>
               <tns:downTimeStart xml:id="id_27" xsi:nil="{'true'}">
                  <xsl:value-of xml:id="id_83" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_downtimeDateTime1"/>
               </tns:downTimeStart>
               <tns:workPriority xml:id="id_29">
                  <xsl:value-of xml:id="id_30" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_work_priority1"/>
               </tns:workPriority>
               <tns:workClass xml:id="id_31">
                  <xsl:value-of xml:id="id_32" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_work_class1"/>
               </tns:workClass>
               <tns:workCategory xml:id="id_33">
                  <xsl:value-of xml:id="id_34" select="/nssrcmpr:notify_POST/nssrcmpr:events.definitions.requestEvent/ns27:requestChanges/ns26:wam_pickup_work_category1"/>
               </tns:workCategory>
            <tns:requestor xml:id="id_52">
                  <xsl:value-of xml:id="id_112" select="$defaultUser"/>
               </tns:requestor>
            <tns:employeeExternalId xml:id="id_121">
                  <xsl:value-of xml:id="id_122" select="$userIDVar"/>
               </tns:employeeExternalId>
            </tns:input>
         </tns:W1-CreMoblWR>
      </nstrgmpr:W1-CreMoblWR>
   </xsl:template>
</xsl:stylesheet>