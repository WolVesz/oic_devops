<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xml:id="id_1" xmlns:nssrcmpr="http://www.oracle.com/2014/03/ics/schedule" xmlns:ns1="http://xmlns.oracle.com/cloud/adapter/REST/PutWorkClass_REQUEST" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:ns2="http://xmlns.oracle.com/cloud/generic/rest/fault/REST/PutWorkClass" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:nstrgmpr="http://xmlns.oracle.com/cloud/adapter/REST/PutWorkClass_REQUEST/types" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:nsmpr0="http://xml.oracle.com/adapters/extension" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:nstrgdfl="http://xmlns.oracle.com/cloud/adapter/REST/PutWorkClass/types" exclude-result-prefixes=" nssrcmpr oraext xsd xp20 ora oracle-xsl-mapper xsi fn nsmpr0 xsl ignore01" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" ignore01:ignorexmlids="true" xmlns:nsmpr1="http://xmlns.oracle.com/cloud/adapter/Oracle_Utilities/ref/types" xmlns:nsmpr2="http://xmlns.oracle.com/cloud/adapter/REST/Get_OFSCWorkSkillConditions_REQUEST/types" xmlns:nsmpr3="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:xml="http://www.w3.org/XML/1998/namespace" xmlns:orajs11="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1667070767" xmlns:nxsd="http://xmlns.oracle.com/pcbpel/nxsd" xmlns:plnk="http://schemas.xmlsoap.org/ws/2003/05/partner-link/" xmlns:orajs13="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath948039040" xmlns:orajs5="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1681625448" xmlns:orajs0="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath56919032" xmlns:orajs2="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1396154174" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:ns30="http://xmlns.oracle.com/cloud/adapter/REST/Get_OFSCWorkSkillConditions_REQUEST" xmlns:orajs10="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1429540732" xmlns:orajs6="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1485347291" xmlns:orajs12="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath877648652" xmlns:ns28="http://xmlns.oracle.com/cloud/adapter/connectivityproperties/REST/Get_OFSCWorkSkillConditions_REQUEST/RESTOUTREQ" xmlns:orajs8="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath761874789" xmlns:ns34="http://xmlns.oracle.com/cloud/adapter/connectivityproperties/REST/PutWorkClass_REQUEST/RESTOUTREQ" xmlns:wssutil="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:orajs9="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath673895125" xmlns:ns26="http://xmlns.oracle.com/cloud/adapter/Oracle_Utilities/ref" xmlns:orajs1="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1635443809" xmlns:ns31="http://xmlns.oracle.com/cloud/generic/rest/fault/REST/Get_OFSCWorkSkillConditions" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.dvm.DVMFunctions" xmlns:connprop="http://xmlns.oracle.com/cloud/adapter/connectivityproperties" xmlns:orajs4="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1486200524" xmlns:ns21="http://ouaf.oracle.com/" xmlns:orajs3="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1596616741" xmlns:orajs14="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath86288" xmlns:wsp="http://www.w3.org/ns/ws-policy" xmlns:ns3="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:tns="http://ouaf.oracle.com/webservices/w1/W1-ExtMobileControlData" xmlns:ns0="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:orajs7="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1634410945" xmlns:ns32="http://xmlns.oracle.com/cloud/adapter/REST/Get_OFSCWorkSkillConditions/types">
   <oracle-xsl-mapper:schema xml:id="id_2">
      <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
      <oracle-xsl-mapper:mapSources xml:id="id_3">
         <oracle-xsl-mapper:source type="XSD" xml:id="id_4">
            <oracle-xsl-mapper:schema location="../../processor_8/resourcegroup_9/ICSSchedule_1.xsd" xml:id="id_5"/>
            <oracle-xsl-mapper:rootElement name="schedule" namespace="http://www.oracle.com/2014/03/ics/schedule" xml:id="id_6"/>
         </oracle-xsl-mapper:source>
      <oracle-xsl-mapper:source type="WSDL" xml:id="id_13">
            <oracle-xsl-mapper:schema location="../../application_3967/inbound_3968/resourcegroup_3969/Get_MobileControlData_REQUEST.wsdl" xml:id="id_14"/>
            <oracle-xsl-mapper:rootElement name="W1-ExtMbCnDaResponse" namespace="http://xmlns.oracle.com/cloud/adapter/Oracle_Utilities/ref/types" xml:id="id_15"/>
            <oracle-xsl-mapper:param name="Get_MobileControlData" xml:id="id_16"/>
         </oracle-xsl-mapper:source>
      </oracle-xsl-mapper:mapSources>
      <oracle-xsl-mapper:mapTargets xml:id="id_7">
         <oracle-xsl-mapper:target type="WSDL" xml:id="id_8">
            <oracle-xsl-mapper:schema location="../../application_9056/inbound_9057/resourcegroup_9058/PutWorkClass_REQUEST.wsdl" xml:id="id_9"/>
            <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/PutWorkClass_REQUEST/types" xml:id="id_10"/>
         </oracle-xsl-mapper:target>
      </oracle-xsl-mapper:mapTargets>
      <!--GENERATED BY ORACLE XSL MAPPER 12.1.2.0.0-->
   </oracle-xsl-mapper:schema>
   <!--User Editing allowed BELOW this line - DO NOT DELETE THIS LINE-->
   <xsl:param name="ActiveFlag_Default" xml:id="id_33"/>
   <xsl:param name="Get_MobileControlData" xml:id="id_34"/>
   <xsl:param name="Language" xml:id="id_38"/>
   <xsl:template match="/" xml:id="id_11">
      <nstrgmpr:execute xml:id="id_12">
         <nstrgdfl:request-wrapper xml:id="id_65">
            <xsl:for-each xml:id="id_72" select="$Get_MobileControlData/nsmpr1:W1-ExtMbCnDaResponse/tns:W1-ExtMbCnDa/tns:output/tns:workClass/tns:workClassList">
               <nstrgdfl:items xml:id="id_73">
                  <nstrgdfl:label xml:id="id_79">
                     <xsl:value-of xml:id="id_80" select="tns:workClass"/>
                  </nstrgdfl:label>
                  <nstrgdfl:active xml:id="id_74">
                     <xsl:value-of xml:id="id_75" select="$ActiveFlag_Default"/>
                  </nstrgdfl:active>
                  <nstrgdfl:translations xml:id="id_76">
                     <nstrgdfl:language xml:id="id_77">
                        <xsl:value-of xml:id="id_78" select="$Language"/>
                     </nstrgdfl:language>
					 <xsl:variable name="categories">
					    <xsl:choose>
						   <xsl:when test="tns:workCategoryList">
							   <xsl:value-of select="tns:workCategoryList/tns:workCategory" separator="|"/>
						   </xsl:when>
						   <xsl:otherwise>
						     <xsl:for-each xml:id="id_92" select="$Get_MobileControlData/nsmpr1:W1-ExtMbCnDaResponse/tns:W1-ExtMbCnDa/tns:output/tns:controlDataEntities/tns:entity[tns:mo = &quot;W1-WORKCAT&quot;]/tns:code">
                              <xsl:if test="position() > 1 ">|</xsl:if>
					              <xsl:value-of xml:id="id_93" select="."/>
                             </xsl:for-each>
						   </xsl:otherwise>
						</xsl:choose>
				     </xsl:variable>
                     <nstrgdfl:name xml:id="id_81">
                        <xsl:value-of xml:id="id_82" select="concat(tns:description, '|', $categories)"/>
                     </nstrgdfl:name>
                  </nstrgdfl:translations>
               </nstrgdfl:items>
            </xsl:for-each>
         </nstrgdfl:request-wrapper>
      </nstrgmpr:execute>
   </xsl:template>
</xsl:stylesheet>