<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:rptw="http://xmlns.oracle.com/types/RunChecklistReport/1632595121543/OutboundSOAPRequestDocument" xmlns:report="http://xmlns.oracle.com/oxp/service/PublicReportService" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:srcr="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST/types" xmlns:src="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger/types" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" xml:id="id_1" exclude-result-prefixes=" oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ns1 ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/Trigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/Trigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_47/inbound_48/resourcegroup_49/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_25/inbound_26/resourcegroup_27/SubmitExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="submitAndGetFlowInstanceIdResponse" namespace="http://xmlns.oracle.com/cloud/adapter/hcm/SubmitExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="SubmitExtract"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_25/inbound_26/resourcegroup_27/SubmitExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="submitAndGetFlowInstanceId" namespace="http://xmlns.oracle.com/cloud/adapter/hcm/SubmitExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="SubmitExtract_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_64/resourcegroup_65/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_191/inbound_192/resourcegroup_193/SearchStatus_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/SearchStatus/1690742339734/OutboundSOAPRequestDocument"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="DocumentID"/>
	<xsl:param name="DownloadFileReference"/>
	<xsl:param name="IsProcessOver"/>
	<xsl:param name="Now"/>
	<xsl:param name="SubmitExtract"/>
	<xsl:param name="SubmitExtract_REQUEST"/>
	<xsl:param name="loopIndex"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<rptw:OutboundSOAPRequestDocument>
			<rptw:Body>
				<report:runReport>
					<report:reportRequest>
						<report:parameterNameValues>
							<report:item>
								<report:name>p_flow_instance_name</report:name>
								<report:values>
									<report:item>
										<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='ExtractName']/cfg:Value,'-',xp20:format-dateTime($Now,'[Y0001][M01][D01][H01][m01][s01]'))"/>
									</report:item>
								</report:values>
							</report:item>
						</report:parameterNameValues>
						<report:reportAbsolutePath>
							<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='ExtractStatusReport']/cfg:Value"/>
						</report:reportAbsolutePath>
					    <report:sizeOfDataChunkDownload>-1</report:sizeOfDataChunkDownload>
					</report:reportRequest>
				</report:runReport>
			</rptw:Body>
		</rptw:OutboundSOAPRequestDocument>
	</xsl:template>
</xsl:stylesheet>