<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:audr="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing4Employee_REQUEST/types" xmlns:aud="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing4Employee/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:delta="http://xmlns.oracle.com/cloud/adapter/REST/GetNextDelta/types" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:outt="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST/types" xmlns:out="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger/types" xmlns:med="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:ic="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:fault="http://www.oracle.com/2014/03/ics/fault" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:nssrcdfl="http://xmlns.oracle.com/procmon" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" exclude-result-prefixes=" ns3 oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">
        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/OutboundTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_544/resourcegroup_545/ICSFault.xsd"/>
                          <oracle-xsl-mapper:rootElement name="fault" namespace="http://www.oracle.com/2014/03/ics/fault"/>
                          <oracle-xsl-mapper:param name="Scope_EachEmployeeFaultObject"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_25/resourcegroup_26/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1319/inbound_1320/resourcegroup_1321/PublishAuditing4Employee_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing4Employee_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
        <xsl:param name="Scope_EachEmployeeFaultObject"/>
        <xsl:param name="self"/>
        <xsl:template match="/">
              <audr:execute>
                    <aud:request-wrapper>
                          <aud:Auditing>
                                <aud:AuditingType>
                                      <xsl:value-of select="'Error'"/>
                                </aud:AuditingType>
                                <aud:FlowInstanceID>
                                      <xsl:value-of select="ic:getFlowId()"/>
                                </aud:FlowInstanceID>
                                <aud:TrackingID>
                                      <xsl:value-of select="/outt:execute/out:request-wrapper/out:EmployeeOutbound/out:BatchID"/>
                                </aud:TrackingID>
                                <aud:ReferenceID>
                                      <xsl:value-of select="concat ($self/med:metadata/med:integration/med:name, '-', /outt:execute/out:request-wrapper/out:EmployeeOutbound/out:StartTime )"/>
                                </aud:ReferenceID>
                                <aud:InterfaceName>
                                      <xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
                                </aud:InterfaceName>
                                <aud:Title>
                                      <xsl:value-of select="concat($self/med:metadata/med:integration/med:name, ' - Employee record - Error - ', ic:getFlowId())"/>
                                </aud:Title>
                                <aud:Details>
                                      <xsl:value-of select="concat ('ErrorCode:', $Scope_EachEmployeeFaultObject/fault:fault/fault:errorCode, '; reason:', $Scope_EachEmployeeFaultObject/fault:fault/fault:reason, '; details:', $Scope_EachEmployeeFaultObject/fault:fault/fault:details )"/>
                                </aud:Details>
                                <aud:Payload>
                                      <xsl:value-of select="oraext:get-content-as-string(/outt:execute/out:request-wrapper/out:EmployeeOutbound)"/>
                                </aud:Payload>
                                <aud:AuditingID>
                                      <xsl:value-of select="oraext:generate-guid ()"/>
                                </aud:AuditingID>
                          </aud:Auditing>
                    </aud:request-wrapper>
              </audr:execute>
        </xsl:template>
  </xsl:stylesheet>