<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:tns="http://medgate.com" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:nstrgmpr="http://xmlns.oracle.com/types/PublishEmployees2Cority/1613076496955/OutboundSOAPRequestDocument" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:nssrcmpr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:nssrcdfl="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:nsmpr0="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:arr="http://schemas.microsoft.com/2003/10/Serialization/Arrays" xmlns:impw="http://xmlns.oracle.com/types/PublishEmployees2Cority/1613076496955/OutboundSOAPRequestDocument" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:nsmpr1="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadHireDates" xmlns:nsmpr2="http://TargetNamespace.com/fileReference/ReadOrgInformation" xmlns:nsmpr3="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" version="2.0" exclude-result-prefixes=" oraext xsd ns7 ora oracle-xsl-mapper fn xsl xp20 nssrcmpr xsi nssrcdfl ignore01 nsmpr1 nsmpr2 nsmpr3" ignore01:ignorexmlids="true">
        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1080/inbound_1081/resourcegroup_1082/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/PublishEmployees2Cority/1613076496955/OutboundSOAPRequestDocument"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
        <xsl:param name="Configs"/>
        <xsl:param name="cority_pswrd"/>
        <xsl:template match="/nssrcmpr:execute">
              <nstrgmpr:OutboundSOAPRequestDocument>
                    <nstrgmpr:Body>
                          <xsl:apply-templates select="nssrcdfl:request-wrapper/nssrcdfl:EmployeesBatch"/>
                    </nstrgmpr:Body>
              </nstrgmpr:OutboundSOAPRequestDocument>
        </xsl:template>
        <xsl:template match="nssrcdfl:EmployeesBatch">
              <tns:ImportCSV>
                    <tns:data/>
                    <tns:importFormat>EmployeeNumber,FirstName,LastName,LoginId,MiddleName,NickName,HomeStreet1,HomeStreet2,HomeCity,HomeState.Code,HomeZip,HomePhone,WorkPhone,Email,DateOfBirth,DateOfHire,DateOfTermination,Union.Code,Organization.Code,Location.Code,Location.Description,Supervisor.EmployeeNumber,JobPosition.Code,JobPosition.Description,Gender			</tns:importFormat>
                    <tns:dateFormat>mm/dd/yyyy</tns:dateFormat>
                    <tns:ignoreIncorrectNumFields>false</tns:ignoreIncorrectNumFields>
                    <tns:disableHEGUpdate>false</tns:disableHEGUpdate>
                    <tns:updateBaseTableDescriptions>true</tns:updateBaseTableDescriptions>
                    <tns:username>
                          <xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='Username']/cfg:Value"/>
                    </tns:username>
                    <tns:password>
                          <xsl:value-of select="oraext:decodeBase64($cority_pswrd)"/>
                    </tns:password>
                    <tns:updateExistingRecords>true</tns:updateExistingRecords>
                    <tns:insertNonExistingBaseTableValues>true</tns:insertNonExistingBaseTableValues>
                    <tns:mergeRecordsMatchingSSN>false</tns:mergeRecordsMatchingSSN>
                    <tns:containsHeaderRow>false</tns:containsHeaderRow>
                    <tns:autoCreatePortalUser>true</tns:autoCreatePortalUser>
              </tns:ImportCSV>
        </xsl:template>
  </xsl:stylesheet>