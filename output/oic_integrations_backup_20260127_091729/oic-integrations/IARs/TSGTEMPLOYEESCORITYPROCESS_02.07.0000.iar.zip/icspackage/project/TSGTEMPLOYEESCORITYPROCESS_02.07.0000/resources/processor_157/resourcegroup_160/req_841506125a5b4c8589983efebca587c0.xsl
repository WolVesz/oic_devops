<xsl:stylesheet xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:wsam="http://www.w3.org/2007/05/addressing/metadata" xmlns:arr="http://schemas.microsoft.com/2003/10/Serialization/Arrays" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:tns="http://medgate.com" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:nstrgmpr="http://xmlns.oracle.com/types/PublishEmployees2Cority/1613076496955/OutboundSOAPRequestDocument" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:nssrcmpr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:empt="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:nsmpr1="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:dpt="http://xmlns.oracle.com/cloud/adapter/REST/GetDepartment/types" xmlns:deptr="http://xmlns.oracle.com/cloud/adapter/REST/GetDepartment_REQUEST/types" xmlns:locf="http://xmlns.oracle.com/cloud/adapter/REST/GetLocationDFF/types" xmlns:locfr="http://xmlns.oracle.com/cloud/adapter/REST/GetLocationDFF_REQUEST/types" xmlns:loc="http://xmlns.oracle.com/cloud/adapter/REST/GetLocation/types" xmlns:locr="http://xmlns.oracle.com/cloud/adapter/REST/GetLocation_REQUEST/types" xmlns:job="http://xmlns.oracle.com/cloud/adapter/REST/GetJob/types" xmlns:jobr="http://xmlns.oracle.com/cloud/adapter/REST/GetJob_REQUEST/types" xmlns:gmr="http://xmlns.oracle.com/cloud/adapter/REST/GetManager_REQUEST/types" xmlns:gm="http://xmlns.oracle.com/cloud/adapter/REST/GetManager/types" xmlns:pt="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types" xmlns:workerr="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker_REQUEST/types" xmlns:worker="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker/types" xmlns:org="http://TargetNamespace.com/fileReference/ReadOrgInformation" xmlns:hr="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadHireDates" xmlns:nxsd="http://xmlns.oracle.com/pcbpel/nxsd" version="2.0" exclude-result-prefixes=" oraext xsd ora oracle-xsl-mapper fn xsl xp20 nssrcmpr xsi nssrcdfl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1080/inbound_1081/resourcegroup_1082/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ImportCSV" namespace="http://medgate.com"/>
                          <oracle-xsl-mapper:param name="CorityRequest"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_87/resourcegroup_94/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Employees" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types"/>
                          <oracle-xsl-mapper:param name="Employee"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_302/inbound_303/resourcegroup_304/GetJob_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetJob_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetJob"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_302/inbound_303/resourcegroup_304/GetJob_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetJob_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetJob_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_285/inbound_286/resourcegroup_287/GetLocation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetLocation_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetLocation"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_285/inbound_286/resourcegroup_287/GetLocation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetLocation_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetLocation_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_421/inbound_422/resourcegroup_423/GetManager_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetManager_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetManager"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_421/inbound_422/resourcegroup_423/GetManager_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetManager_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetManager_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_246/inbound_247/resourcegroup_248/GetWorker_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetWorker"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_246/inbound_247/resourcegroup_248/GetWorker_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetWorker_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_1197/resourcegroup_1198/ReadHireDates_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="DATA_DS" namespace="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadHireDates"/>
                          <oracle-xsl-mapper:param name="HireDates"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_742/resourcegroup_743/ReadOrgInformation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Organizations" namespace="http://TargetNamespace.com/fileReference/ReadOrgInformation"/>
                          <oracle-xsl-mapper:param name="Organizations"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_569/inbound_570/resourcegroup_571/GetPersonTypes_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types"/>
                          <oracle-xsl-mapper:param name="PersonTypes"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_58/resourcegroup_59/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/PublishEmployees2Cority/1613076496955/OutboundSOAPRequestDocument"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="CorityRequest"/>
	<xsl:param name="Employee"/>
	<xsl:param name="GetJob"/>
	<xsl:param name="GetJob_REQUEST"/>
	<xsl:param name="GetLocation"/>
	<xsl:param name="GetLocation_REQUEST"/>
	<xsl:param name="GetManager"/>
	<xsl:param name="GetManager_REQUEST"/>
	<xsl:param name="GetWorker"/>
	<xsl:param name="GetWorker_REQUEST"/>
	<xsl:param name="HireDates"/>
	<xsl:param name="Organizations"/>
	<xsl:param name="PersonTypes"/>
	<xsl:param name="count"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<nstrgmpr:OutboundSOAPRequestDocument>
			<xsl:variable name="employeetype" select="$PersonTypes/pt:response-wrapper/pt:items[pt:UserPersonType='Employee']/pt:PersonTypeId"/>
			<xsl:variable name="contractortype" select="$PersonTypes/pt:response-wrapper/pt:items[pt:UserPersonType='Contingent Worker']/pt:PersonTypeId"/>
			<xsl:variable name="pendingtype" select="$PersonTypes/pt:response-wrapper/pt:items[pt:UserPersonType='Pending Worker']/pt:PersonTypeId"/>

			<xsl:variable name="workRelationships">
				<xsl:choose>
					<xsl:when test="count($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'ACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))])>0]) > 0">
						<xsl:copy-of select="$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'ACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))])>0][1]"/>
					</xsl:when>
					<xsl:when test="count($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'INACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))])>0]) > 0">
						<xsl:copy-of select="$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'INACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))])>0][1]"/>
					</xsl:when>
				</xsl:choose>
			</xsl:variable>

			<xsl:variable name="assignment">
				<xsl:choose>
					<xsl:when test="($workRelationships/worker:workRelationships/worker:WorkerType = 'E' or $workRelationships/worker:workRelationships/worker:WorkerType = 'C') and count($workRelationships/worker:workRelationships/worker:assignments[worker:AssignmentStatusType = 'ACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))]) > 0">
						<xsl:copy-of select="$workRelationships/worker:workRelationships/worker:assignments[worker:AssignmentStatusType = 'ACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))][1]"/>
					</xsl:when>
					<xsl:when test="$workRelationships/worker:workRelationships/worker:WorkerType = 'E' and count($workRelationships/worker:workRelationships/worker:assignments[worker:AssignmentStatusType = 'INACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))]) > 0">
						<xsl:copy-of select="$workRelationships/worker:workRelationships/worker:assignments[worker:AssignmentStatusType = 'INACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))][1]"/>
					</xsl:when>
				
				</xsl:choose>
			</xsl:variable>

			<xsl:variable name="unionCode">
				<xsl:choose>
					<xsl:when test="((not(boolean(string(normalize-space($assignment/worker:assignments/worker:LabourUnionMemberFlag)))) or $assignment/worker:assignments/worker:LabourUnionMemberFlag='No') and not(boolean(string($assignment/worker:assignments/worker:GradeLadderName))) ) or starts-with($assignment/worker:assignments/worker:GradeLadderName,'CCC')">Non-Bargaining</xsl:when>
					<xsl:when test="$assignment/worker:assignments/worker:LabourUnionMemberFlag='Yes'">Bargaining</xsl:when>
					<xsl:when test="((not(boolean(string(normalize-space($assignment/worker:assignments/worker:LabourUnionMemberFlag)))) or $assignment/worker:assignments/worker:LabourUnionMemberFlag='No') and boolean(string($assignment/worker:assignments/worker:GradeLadderName))) or not(starts-with($assignment/worker:assignments/worker:GradeLadderName,'CCC'))">Non-Barg T&amp;C</xsl:when>
				</xsl:choose>
			</xsl:variable>

			<nstrgmpr:Body>
				<tns:ImportCSV>
					<xsl:for-each select="$CorityRequest/tns:ImportCSV">
						<tns:data>
							<xsl:for-each select="tns:data/arr:string">
								<xsl:copy-of select="."/>
							</xsl:for-each>

							
							<xsl:variable name="homePhone">
								<xsl:choose>
									<xsl:when test="boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='H1']/worker:AreaCode))) and boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='H1']/worker:PhoneNumber)))">
										<xsl:value-of select="concat(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='H1']/worker:AreaCode)), '-', normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='H1']/worker:PhoneNumber)))"/>
									</xsl:when>
									<xsl:when test="not(boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='H1']/worker:AreaCode)))) and boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='H1']/worker:PhoneNumber)))">
										<xsl:value-of select="normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='H1']/worker:PhoneNumber))"/>
									</xsl:when>
								</xsl:choose>
							</xsl:variable>

							<xsl:variable name="workPhone">
								<xsl:choose>
									<xsl:when test="boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='W1']/worker:AreaCode))) and boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='W1']/worker:PhoneNumber)))">
										<xsl:value-of select="concat(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='W1']/worker:AreaCode)), '-', normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='W1']/worker:PhoneNumber)))"/>

									</xsl:when>
									<xsl:when test="not(boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='W1']/worker:AreaCode)))) and boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='W1']/worker:PhoneNumber)))">
										<xsl:value-of select="normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:phones[worker:PhoneType='W1']/worker:PhoneNumber))"/>
									</xsl:when>
								</xsl:choose>
							</xsl:variable>
							
							<xsl:variable name="personNumber" select="$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:PersonNumber"/>

							<xsl:variable name="birthday">
								<xsl:choose>
									<xsl:when test="boolean(normalize-space(string($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:DateOfBirth)))">
										<xsl:value-of select="xp20:format-dateTime($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:DateOfBirth,'[M01]/[D01]/[Y0001]')"/>
									</xsl:when>
								</xsl:choose>
							</xsl:variable>

							<xsl:variable name="hireDate">
								<xsl:choose>
									<xsl:when test="boolean(normalize-space(string($HireDates/hr:DATA_DS/hr:G_1[hr:PERSON_NUMBER=string($personNumber)][1]/hr:ORIGINAL_DATE)))">
										<xsl:value-of select="xp20:format-dateTime($HireDates/hr:DATA_DS/hr:G_1[hr:PERSON_NUMBER=string($personNumber)][1]/hr:ORIGINAL_DATE,'[M01]/[D01]/[Y0001]')"/>
									</xsl:when>
									<xsl:when test="boolean(normalize-space(string($HireDates/hr:DATA_DS/hr:G_1[hr:PERSON_NUMBER=string($personNumber)][1]/hr:LATEST_HIRE_DATE))) and $assignment/worker:assignments/worker:ActionCode = 'REHIRE'">
										<xsl:value-of select="xp20:format-dateTime($HireDates/hr:DATA_DS/hr:G_1[hr:PERSON_NUMBER=string($personNumber)][1]/hr:LATEST_HIRE_DATE,'[M01]/[D01]/[Y0001]')"/>
									</xsl:when>
									<xsl:when test="boolean(normalize-space(string($HireDates/hr:DATA_DS/hr:G_1[hr:PERSON_NUMBER=string($personNumber)][1]/hr:ENTERPRISE_DATE)))">
										<xsl:value-of select="xp20:format-dateTime($HireDates/hr:DATA_DS/hr:G_1[hr:PERSON_NUMBER=string($personNumber)][1]/hr:ENTERPRISE_DATE,'[M01]/[D01]/[Y0001]')"/>
									</xsl:when>
								</xsl:choose>
							</xsl:variable>

							<xsl:variable name="terminationDate">
								<xsl:choose>
									<xsl:when test="boolean(normalize-space(string($workRelationships/worker:workRelationships/worker:TerminationDate)))">
										<xsl:value-of select="xp20:format-dateTime($workRelationships/worker:workRelationships/worker:TerminationDate,'[M01]/[D01]/[Y0001]')"/>
									</xsl:when>
								</xsl:choose>
							</xsl:variable>

							<xsl:variable name="jobCode">
								<xsl:choose>
									<xsl:when test="contains($GetJob/jobr:executeResponse/job:response-wrapper/job:items[1]/job:JobCode,',')">
										<xsl:value-of select="concat('&quot;',$GetJob/jobr:executeResponse/job:response-wrapper/job:items[1]/job:JobCode,'&quot;')"/>
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$GetJob/jobr:executeResponse/job:response-wrapper/job:items[1]/job:JobCode"/>
									</xsl:otherwise>
								</xsl:choose>
							</xsl:variable>

							<xsl:variable name="jobName">
								<xsl:choose>
									<xsl:when test="contains($GetJob/jobr:executeResponse/job:response-wrapper/job:items[1]/job:Name,',')">
										<xsl:value-of select="concat('&quot;',$GetJob/jobr:executeResponse/job:response-wrapper/job:items[1]/job:Name,'&quot;')"/>
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$GetJob/jobr:executeResponse/job:response-wrapper/job:items[1]/job:Name"/>
									</xsl:otherwise>
								</xsl:choose>
							</xsl:variable>

							<xsl:variable name="locationName">
								<xsl:choose>
									<xsl:when test="contains($GetLocation/locr:executeResponse/loc:response-wrapper/loc:items[1]/loc:LocationName,',')">
										<xsl:value-of select="concat('&quot;',$GetLocation/locr:executeResponse/loc:response-wrapper/loc:items[1]/loc:LocationName,'&quot;')"/>
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$GetLocation/locr:executeResponse/loc:response-wrapper/loc:items[1]/loc:LocationName"/>
									</xsl:otherwise>
								</xsl:choose>
							</xsl:variable>
							
							<xsl:variable name="rcn">
								<xsl:choose>
									<xsl:when test="count($Organizations/org:Organizations/org:Organization[org:ORGANIZATION_ID=$assignment/worker:assignments/worker:DepartmentId]) > 0">
										<xsl:value-of select="$Organizations/org:Organizations/org:Organization[org:ORGANIZATION_ID=$assignment/worker:assignments/worker:DepartmentId][1]/org:ORG_INFORMATION1"/>
									</xsl:when>
								</xsl:choose>
							</xsl:variable>

							<xsl:variable name="gender">
								<xsl:choose>
									<xsl:when test="$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:legislativeInfo[worker:LegislationCode='US']/worker:Gender = 'ORA_HRX_X'">
										<xsl:value-of select="' '"/>
									</xsl:when>
									<xsl:otherwise>
										<xsl:value-of select="$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:legislativeInfo[worker:LegislationCode='US']/worker:Gender"/>
									</xsl:otherwise>
								</xsl:choose>
							</xsl:variable>
							
							<arr:string>
								<xsl:value-of select="concat(string($personNumber),',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:names[1]/worker:FirstName,',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:names[1]/worker:LastName,',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:externalIdentifiers[worker:ExternalIdentifierType='NETWORK_ID']/worker:ExternalIdentifierNumber,',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:names[1]/worker:MiddleName,',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:names[1]/worker:KnownAs,',&quot;',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:addresses[1]/worker:AddressLine1,'&quot;,&quot;',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:addresses[1]/worker:AddressLine2,'&quot;,',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:addresses[1]/worker:TownOrCity,',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:addresses[1]/worker:Region2,',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:addresses[1]/worker:PostalCode,',',string($homePhone),',',string($workPhone),',',$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:emails[worker:EmailType='W1']/worker:EmailAddress,',',normalize-space(string($birthday)),',',normalize-space(string($hireDate)),',',normalize-space(string($terminationDate)),',',string($unionCode),',',string($rcn),',',$GetLocation/locr:executeResponse/loc:response-wrapper/loc:items[1]/loc:LocationCode,',',string($locationName),',',$GetManager/gmr:executeResponse/gm:response-wrapper/gm:items[1]/gm:PersonNumber,',',string($jobCode),',',string($jobName),',',string($gender))"/>
							</arr:string>
						</tns:data>
						
						<xsl:copy-of select="./tns:importFormat"/>
						<xsl:copy-of select="./tns:ignoreIncorrectNumFields"/>
						<xsl:copy-of select="./tns:disableHEGUpdate"/>
						<xsl:copy-of select="./tns:updateBaseTableDescriptions"/>
						<xsl:copy-of select="./tns:username"/>
						<xsl:copy-of select="./tns:password"/>
						<xsl:copy-of select="./tns:updateExistingRecords"/>
						<xsl:copy-of select="./tns:insertNonExistingBaseTableValues"/>
						<xsl:copy-of select="./tns:mergeRecordsMatchingSSN"/>
						<xsl:copy-of select="./tns:containsHeaderRow"/>
						<xsl:copy-of select="./tns:autoCreatePortalUser"/>
					</xsl:for-each>
				</tns:ImportCSV>
			</nstrgmpr:Body>
		</nstrgmpr:OutboundSOAPRequestDocument>
	</xsl:template>
</xsl:stylesheet>