<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:jobr="http://xmlns.oracle.com/cloud/adapter/REST/GetJob_REQUEST/types" xmlns:job="http://xml.oracle.com/types/REST/GetJob_REQUEST" xmlns:workerr="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker_REQUEST/types" xmlns:worker="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker/types" xmlns:empt="http://xmlns.oracle.com/cloud/adapter/REST/EmployeesTrigger/types" xmlns:pt="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns1="http://xmlns.oracle.com/cloud/adapter/REST/GetJob_REQUEST" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" xml:id="id_1" exclude-result-prefixes=" ns3 oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">
				
         <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1080/inbound_1081/resourcegroup_1082/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ImportCSV" namespace="http://medgate.com"/>
                          <oracle-xsl-mapper:param name="CorityRequest"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_87/resourcegroup_94/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Employees" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types"/>
                          <oracle-xsl-mapper:param name="Employee"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_285/inbound_286/resourcegroup_287/GetLocation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetLocation_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetLocation"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_285/inbound_286/resourcegroup_287/GetLocation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetLocation_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetLocation_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_246/inbound_247/resourcegroup_248/GetWorker_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetWorker"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_246/inbound_247/resourcegroup_248/GetWorker_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetWorker_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="GetWorker_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_742/resourcegroup_743/ReadOrgInformation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Organizations" namespace="http://TargetNamespace.com/fileReference/ReadOrgInformation"/>
                          <oracle-xsl-mapper:param name="Organizations"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_569/inbound_570/resourcegroup_571/GetPersonTypes_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types"/>
                          <oracle-xsl-mapper:param name="PersonTypes"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_58/resourcegroup_59/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_302/inbound_303/resourcegroup_304/GetJob_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetJob_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="CorityRequest"/>
	<xsl:param name="Employee"/>
	<xsl:param name="GetLocation"/>
	<xsl:param name="GetLocation_REQUEST"/>
	<xsl:param name="GetWorker"/>
	<xsl:param name="GetWorker_REQUEST"/>
	<xsl:param name="Organizations"/>
	<xsl:param name="PersonTypes"/>
	<xsl:param name="count"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<jobr:execute>
			<jobr:QueryParameters>

				<xsl:variable name="employeetype" select="$PersonTypes/pt:response-wrapper/pt:items[pt:UserPersonType='Employee']/pt:PersonTypeId"/>
				<xsl:variable name="contractortype" select="$PersonTypes/pt:response-wrapper/pt:items[pt:UserPersonType='Contingent Worker']/pt:PersonTypeId"/>
				<xsl:variable name="pendingtype" select="$PersonTypes/pt:response-wrapper/pt:items[pt:UserPersonType='Pending Worker']/pt:PersonTypeId"/>

				<xsl:variable name="assignment">
					<xsl:choose>
						<xsl:when test="count($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'ACTIVE'])>0][1]/worker:assignments[worker:AssignmentStatusType = 'ACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))][1]) > 0">
							<xsl:copy-of select="$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'ACTIVE'])>0][1]/worker:assignments[worker:AssignmentStatusType = 'ACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))][1]"/>
						</xsl:when>
						<xsl:when test="count($GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'INACTIVE'])>0][1]/worker:assignments[worker:AssignmentStatusType = 'INACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))][1]) > 0">
							<xsl:copy-of select="$GetWorker/workerr:executeResponse/worker:response-wrapper/worker:items[1]/worker:workRelationships[count(worker:assignments[worker:AssignmentStatusType = 'INACTIVE'])>0][1]/worker:assignments[worker:AssignmentStatusType = 'INACTIVE' and (worker:UserPersonTypeId = string($employeetype) or worker:UserPersonTypeId = string($contractortype))][1]"/>
						</xsl:when>
					</xsl:choose>
				</xsl:variable>
				
				<xsl:variable name="job">
					<xsl:choose>
						<xsl:when test="boolean(normalize-space(string($assignment/worker:assignments/worker:JobId)))">
							<xsl:value-of select="$assignment/worker:assignments/worker:JobId"/>
						</xsl:when>
						<xsl:otherwise>0</xsl:otherwise>
					</xsl:choose>
				</xsl:variable>
				
				<job:q>
					<xsl:value-of select="concat ('JobId=', string($job))"/>
				</job:q>
			</jobr:QueryParameters>
		</jobr:execute>
	</xsl:template>
</xsl:stylesheet>