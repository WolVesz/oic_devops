<xsl:stylesheet version="2.0" xmlns:audr="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing4Employee_REQUEST/types" xmlns:aud="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing4Employee/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:fault="http://www.oracle.com/2014/03/ics/fault" xmlns:med="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:emp="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:oic="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:ic="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:empt="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" exclude-result-prefixes=" oraext xp20 ora oracle-xsl-mapper nssrcdfl xsi fn xsl nsmpr0 ignore01" ignore01:ignorexmlids="true">
				

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1080/inbound_1081/resourcegroup_1082/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ImportCSV" namespace="http://medgate.com"/>
                          <oracle-xsl-mapper:param name="CorityRequest"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_87/resourcegroup_94/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Employees" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types"/>
                          <oracle-xsl-mapper:param name="Employee"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_742/resourcegroup_743/ReadOrgInformation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Organizations" namespace="http://TargetNamespace.com/fileReference/ReadOrgInformation"/>
                          <oracle-xsl-mapper:param name="Organizations"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_569/inbound_570/resourcegroup_571/GetPersonTypes_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types"/>
                          <oracle-xsl-mapper:param name="PersonTypes"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_443/resourcegroup_444/ICSFault.xsd"/>
                          <oracle-xsl-mapper:rootElement name="fault" namespace="http://www.oracle.com/2014/03/ics/fault"/>
                          <oracle-xsl-mapper:param name="Scope_GetDetailsFaultObject"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_58/resourcegroup_59/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1136/inbound_1137/resourcegroup_1138/PublishAuditing4Employee_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing4Employee_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="CorityRequest"/>
	<xsl:param name="Employee"/>
	<xsl:param name="Organizations"/>
	<xsl:param name="PersonTypes"/>
	<xsl:param name="Scope_GetDetailsFaultObject"/>
	<xsl:param name="count"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<audr:execute>
			<aud:request-wrapper>
				<aud:Auditing>
					<aud:AuditingType>
						<xsl:value-of select="'Error'"/>
					</aud:AuditingType>
					<aud:FlowInstanceID>
						<xsl:value-of select="ic:getFlowId()"/>
					</aud:FlowInstanceID>
					<aud:TrackingID>
						<xsl:value-of select="/nssrcmpr:execute/empt:request-wrapper/empt:EmployeesBatch/empt:BatchID"/>
					</aud:TrackingID>
					<aud:ReferenceID>
						<xsl:value-of select="concat ($self/med:metadata/med:integration/med:name, '-', /nssrcmpr:execute/empt:request-wrapper/empt:EmployeesBatch/empt:DateTime )"/>
					</aud:ReferenceID>
					<aud:InterfaceName>
						<xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
					</aud:InterfaceName>
					<aud:Title>
						<xsl:value-of select="concat($self/med:metadata/med:integration/med:name, ' - Employee record - Error - ', ic:getFlowId())"/>
					</aud:Title>
					<aud:Details>
						<xsl:value-of select="concat ('ErrorCode:', $Scope_GetDetailsFaultObject/fault:fault/fault:errorCode, '; reason:', $Scope_GetDetailsFaultObject/fault:fault/fault:reason, '; details:', $Scope_GetDetailsFaultObject/fault:fault/fault:details )"/>
					</aud:Details>
					<aud:Payload>
						<xsl:value-of select="oraext:get-content-as-string($Employee/emp:Employees)"/>
					</aud:Payload>
					<aud:AuditingID>
						<xsl:value-of select="oraext:generate-guid ()"/>
					</aud:AuditingID>
				</aud:Auditing>
			</aud:request-wrapper>
		</audr:execute>
	</xsl:template>
</xsl:stylesheet>