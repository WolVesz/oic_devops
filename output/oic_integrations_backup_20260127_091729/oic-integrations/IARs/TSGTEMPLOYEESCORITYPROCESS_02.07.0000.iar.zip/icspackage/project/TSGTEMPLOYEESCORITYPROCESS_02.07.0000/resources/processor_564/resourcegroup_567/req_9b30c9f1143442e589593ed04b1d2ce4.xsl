<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:impw="http://xmlns.oracle.com/types/PublishEmployees2Cority/1613076496955/OutboundSOAPRequestDocument" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:tns="http://medgate.com" xmlns:wsac="http://www.w3.org/2005/08/addressing" xmlns:wsap="http://schemas.xmlsoap.org/ws/2004/08/addressing/policy" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:wsa="http://schemas.xmlsoap.org/ws/2004/08/addressing" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" xml:id="id_1" exclude-result-prefixes=" oraext xsd ns11 ora oracle-xsl-mapper fn xsl xp20 nssrcmpr nssrcdfl xsi ignore01" ignore01:ignorexmlids="true">
				

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1080/inbound_1081/resourcegroup_1082/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ImportCSV" namespace="http://medgate.com"/>
                          <oracle-xsl-mapper:param name="CorityRequest"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_742/resourcegroup_743/ReadOrgInformation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Organizations" namespace="http://TargetNamespace.com/fileReference/ReadOrgInformation"/>
                          <oracle-xsl-mapper:param name="Organizations"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_569/inbound_570/resourcegroup_571/GetPersonTypes_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types"/>
                          <oracle-xsl-mapper:param name="PersonTypes"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_58/resourcegroup_59/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/PublishEmployees2Cority/1613076496955/OutboundSOAPRequestDocument"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="CorityRequest"/>
	<xsl:param name="Organizations"/>
	<xsl:param name="PersonTypes"/>
	<xsl:param name="count"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<impw:OutboundSOAPRequestDocument>
			<impw:Headers>
				  <impw:CustomSOAPHeaders>
						<wsac:Action>
							  <xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='SOAPAction']/cfg:Value"/>
						</wsac:Action>
				  </impw:CustomSOAPHeaders>
			</impw:Headers>
			<impw:ConnectivityProperties>
				  <impw:EndpointProperties>
						<impw:EndpointURI>
							  <xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='Endpoint']/cfg:Value"/>
						</impw:EndpointURI>
				  </impw:EndpointProperties>
			</impw:ConnectivityProperties>

			<impw:Body>
				<xsl:copy-of select="$CorityRequest/tns:ImportCSV"/>
			</impw:Body>
		</impw:OutboundSOAPRequestDocument>
			  
	</xsl:template>
</xsl:stylesheet>