<xsl:stylesheet xmlns:rptw="http://xmlns.oracle.com/types/RunDepartmentReport/1621887598409/OutboundSOAPRequestDocument" xmlns:report="http://xmlns.oracle.com/oxp/service/PublicReportService" xmlns:tgrr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types" xmlns:tgr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" xml:id="id_1" exclude-result-prefixes=" oraext nssrcdfl xsd xp20 ora nssrcmpr oracle-xsl-mapper xsi fn xsl ns1 ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1080/inbound_1081/resourcegroup_1082/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_43/inbound_44/resourcegroup_45/PublishEmployees2Cority_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ImportCSV" namespace="http://medgate.com"/>
                          <oracle-xsl-mapper:param name="CorityRequest"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_1197/resourcegroup_1198/ReadHireDates_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="DATA_DS" namespace="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadHireDates"/>
                          <oracle-xsl-mapper:param name="HireDates"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_742/resourcegroup_743/ReadOrgInformation_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Organizations" namespace="http://TargetNamespace.com/fileReference/ReadOrgInformation"/>
                          <oracle-xsl-mapper:param name="Organizations"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_569/inbound_570/resourcegroup_571/GetPersonTypes_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetPersonTypes/types"/>
                          <oracle-xsl-mapper:param name="PersonTypes"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_58/resourcegroup_59/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1155/inbound_1156/resourcegroup_1157/GetHireDates_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/GetHireDates/1735615463487/OutboundSOAPRequestDocument"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="CorityRequest"/>
	<xsl:param name="HireDates"/>
	<xsl:param name="Organizations"/>
	<xsl:param name="PersonTypes"/>
	<xsl:param name="count"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
    <xsl:template name="printPersonNumber">
        <xsl:param name="nodes"/>

        <xsl:for-each select="$nodes">
            <xsl:choose>
                <xsl:when test="position() != last()">
					<xsl:value-of select="concat(./tgr:PersonNumber,',')"/>
                </xsl:when>
                <xsl:otherwise>
					<xsl:value-of select="./tgr:PersonNumber"/>
                </xsl:otherwise>
            </xsl:choose>
        </xsl:for-each>
    </xsl:template>
	
	<xsl:variable name="numbers">
		<xsl:call-template name="printPersonNumber">
			<xsl:with-param name="nodes" select="/tgrr:execute/tgr:request-wrapper/tgr:EmployeesBatch/tgr:Employees"/>
		</xsl:call-template>	
	</xsl:variable>
			
	<xsl:template match="/">
		<rptw:OutboundSOAPRequestDocument>
			<rptw:Body>
				<report:runReport>
					<report:reportRequest>
						<report:parameterNameValues>
							<report:item>
								<report:name>p_in_person_numbers</report:name>
								<report:values>
									<report:item>
										<xsl:value-of select="string($numbers)"/>
									</report:item>
								</report:values>
							</report:item>
						</report:parameterNameValues>
						<report:reportAbsolutePath>
							<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='HireDateReport']/cfg:Value"/>
						</report:reportAbsolutePath>
					    <report:sizeOfDataChunkDownload>-1</report:sizeOfDataChunkDownload>
					</report:reportRequest>
				</report:runReport>
			</rptw:Body>
		</rptw:OutboundSOAPRequestDocument>
	</xsl:template>
</xsl:stylesheet>