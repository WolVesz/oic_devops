<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:cfgt="http://xmlns.oracle.com/cloud/adapter/REST/UpdateConfigs_REQUEST/types" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/UpdateConfigs/types" xmlns:med="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns3="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST" xmlns:ns2="http://xmlns.oracle.com/cloud/generic/rest/fault/REST/UpdateConfigs" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" exclude-result-prefixes=" oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ns3 ignore01 nsmpr0" ignore01:ignorexmlids="true" xmlns:nsmpr0="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types">


        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/OutboundTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_25/resourcegroup_26/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              <oracle-xsl-mapper:source type="WSDL">
            <oracle-xsl-mapper:schema location="../../application_832/inbound_833/resourcegroup_834/GetConfigs_REQUEST.wsdl"/>
            <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
            <oracle-xsl-mapper:param name="Configs"/>
         </oracle-xsl-mapper:source>
      </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_774/inbound_775/resourcegroup_776/UpdateConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/UpdateConfigs_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
	<xsl:param name="DeltaLink"/>
	<xsl:param name="NextLink"/>
	<xsl:param name="Round"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>

	<xsl:param name="AllEmployeesSucceed"/>
   <xsl:param name="Configs"/>
   <xsl:template match="/">
		<cfgt:execute>
			<cfg:request-wrapper>
				<xsl:choose>
					<xsl:when test="string-length(string($DeltaLink)) > 3600">
						<cfg:Configs>
							<cfg:Interface>
								  <xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
							</cfg:Interface>
							<cfg:Key>
								  <xsl:value-of select="'DeltaLink'"/>
							</cfg:Key>
							<cfg:Value>
								<xsl:value-of select="substring(string($DeltaLink),1,3600)"/>
							</cfg:Value>
						</cfg:Configs>
						<cfg:Configs>
							<cfg:Interface>
								  <xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
							</cfg:Interface>
							<cfg:Key>
								  <xsl:value-of select="'DeltaLink1'"/>
							</cfg:Key>
							<cfg:Value>
								<xsl:value-of select="substring(string($DeltaLink),3601)"/>
							</cfg:Value>
						</cfg:Configs>
					</xsl:when>
					<xsl:otherwise>
						<cfg:Configs>
							<cfg:Interface>
								  <xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
							</cfg:Interface>
							<cfg:Key>
								  <xsl:value-of select="'DeltaLink'"/>
							</cfg:Key>
							<cfg:Value>
								<xsl:value-of select="string($DeltaLink)"/>
							</cfg:Value>
						</cfg:Configs>
						<cfg:Configs>
							<cfg:Interface>
								  <xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
							</cfg:Interface>
							<cfg:Key>
								  <xsl:value-of select="'DeltaLink1'"/>
							</cfg:Key>
							<cfg:Value/>
						</cfg:Configs>
					</xsl:otherwise>
				</xsl:choose>
			</cfg:request-wrapper>
		</cfgt:execute>
	</xsl:template>
  </xsl:stylesheet>