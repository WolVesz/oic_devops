<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:gdr="http://xmlns.oracle.com/cloud/adapter/REST/GetNextDelta_REQUEST/types" xmlns:gdp="http://xml.oracle.com/types/REST/GetNextDelta_REQUEST" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:gdcp="http://xmlns.oracle.com/cloud/adapter/connectivityproperties/REST/GetNextDelta_REQUEST/RESTOUTREQ" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" exclude-result-prefixes=" oraext nssrcdfl xsd xp20 ora nssrcmpr oracle-xsl-mapper xsi fn xsl nsmpr0 ignore01 nsmpr0" ignore01:ignorexmlids="true" xmlns:nsmpr0="http://www.oracle.com/2014/03/ic/integration/properties">
				
        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_18/outbound_19/resourcegroup_20/OutboundTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_832/inbound_833/resourcegroup_834/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_25/resourcegroup_26/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              <oracle-xsl-mapper:source type="XSD">
            <oracle-xsl-mapper:schema location="../../processor_2934/resourcegroup_2935/ICSIntegrationProperties.xsd"/>
            <oracle-xsl-mapper:rootElement name="properties" namespace="http://www.oracle.com/2014/03/ic/integration/properties"/>
            <oracle-xsl-mapper:param name="selfProperties"/>
         </oracle-xsl-mapper:source>
      </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_154/inbound_155/resourcegroup_156/GetNextDelta_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetNextDelta_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="DeltaLink"/>
	<xsl:param name="NextLink"/>
	<xsl:param name="Round"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:param name="AllEmployeesSucceed"/>
   <xsl:param name="errorsFileName"/>
   <xsl:param name="now"/>
   <xsl:param name="selfProperties"/>
   <xsl:template match="/">
		<gdr:execute>
			<xsl:choose>
				<xsl:when test="number($Round) = 1">

			<gdr:QueryParameters>
				<gdp:_0x646c72_select>
					<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='fields']/cfg:Value"/>
				</gdp:_0x646c72_select>
				<xsl:choose>
					<xsl:when test="boolean(normalize-space(string($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DeltaLink']/cfg:Value))) and boolean(normalize-space(string($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DeltaLink1']/cfg:Value)))">
						<gdp:_0x646c72_deltatoken>
							<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DeltaLink']/cfg:Value,$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DeltaLink1']/cfg:Value)"/>
						</gdp:_0x646c72_deltatoken>
					</xsl:when>
					<xsl:otherwise>
						<gdp:_0x646c72_deltatoken>
							<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DeltaLink']/cfg:Value"/>
						</gdp:_0x646c72_deltatoken>
					</xsl:otherwise>
				</xsl:choose>
			</gdr:QueryParameters>

				</xsl:when>
				<xsl:when test="boolean(normalize-space(string($NextLink)))">

			<gdcp:ConnectivityProperties>
				  <gdcp:RestAPI>
						<gdcp:AbsoluteEndpointURI>
							  <xsl:value-of select="$NextLink"/>
						</gdcp:AbsoluteEndpointURI>
				  </gdcp:RestAPI>
			</gdcp:ConnectivityProperties>
				
				</xsl:when>
			</xsl:choose>
			
		</gdr:execute>
	</xsl:template>
</xsl:stylesheet>