<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:ns0="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:nstrgdfl="http://xmlns.oracle.com/cloud/generic/rest/fault/REST/receiveRequest" xmlns:ns4="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:ns1="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns2="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy/fault/types" xmlns:nstrgmpr="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/types" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:nsmpr10="http://xmlns.oracle.com/cloud/adapter/Oracle_Utilities/AssetQuery_REQUEST/types" xmlns:nsmpr1="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:nsmpr0="http://xmlns.oracle.com/cloud/adapter/oracleutilities/AssetQuery_REQUEST/types" xmlns:orajs1="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1635443809" xmlns:orajs11="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1667070767" xmlns:nxsd="http://xmlns.oracle.com/pcbpel/nxsd" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.dvm.DVMFunctions" xmlns:orajs14="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath948039040" xmlns:orajs4="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1681625448" xmlns:orajs0="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath56919032" xmlns:orajs6="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath123170385" xmlns:orajs2="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1396154174" xmlns:ns23="http://ouaf.oracle.com/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:orajs10="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1429540732" xmlns:ns19="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest/types" xmlns:orajs3="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1596616741" xmlns:ns28="http://ouaf.oracle.com/webservices/w1/W1GAstDtlBNo" xmlns:orajs15="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath86288" xmlns:wsp="http://www.w3.org/ns/ws-policy" xmlns:ns5="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:orajs12="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath877648652" xmlns:orajs8="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath761874789" xmlns:orajs13="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1673207123" xmlns:ns3="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:orajs5="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1634410945" xmlns:wssutil="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:orajs9="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath673895125" xmlns:ns38="http://xmlns.oracle.com/cloud/adapter/oracleutilities/AssetQuery_REQUEST" xmlns:orajs7="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1468259163" version="2.0" xml:id="id_1" exclude-result-prefixes=" oraext xsd xp20 ora oracle-xsl-mapper xsi fn xsl ignore01" ignore01:ignorexmlids="true" xmlns:xml="http://www.w3.org/XML/1998/namespace">
        <oracle-xsl-mapper:schema xml:id="id_2">
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources xml:id="id_3">
                    <oracle-xsl-mapper:source type="WSDL" xml:id="id_4">
                          <oracle-xsl-mapper:schema location="../../application_8/outbound_9/resourcegroup_10/receiveRequest_REQUEST.wsdl" xml:id="id_5"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/types" xml:id="id_6"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL" xml:id="id_13">
                          <oracle-xsl-mapper:schema location="../../application_899/inbound_900/resourcegroup_901/AssetQuery_REQUEST.wsdl" xml:id="id_14"/>
                          <oracle-xsl-mapper:rootElement name="W1GAstDtlBNoResponse" namespace="http://xmlns.oracle.com/cloud/adapter/oracleutilities/AssetQuery_REQUEST/types" xml:id="id_15"/>
                          <oracle-xsl-mapper:param name="AssetQuery" xml:id="id_16"/>
                    </oracle-xsl-mapper:source>
      </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets xml:id="id_7">
                    <oracle-xsl-mapper:target type="WSDL" xml:id="id_8">
                          <oracle-xsl-mapper:schema location="../../application_8/outbound_9/resourcegroup_10/receiveRequest_REQUEST.wsdl" xml:id="id_9"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/types" xml:id="id_10"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
              <!--GENERATED BY ORACLE XSL MAPPER 12.1.2.0.0-->
        </oracle-xsl-mapper:schema>
        <!--User Editing allowed BELOW this line - DO NOT DELETE THIS LINE-->
        <xsl:param name="AssetQuery" xml:id="id_25"/>
   <xsl:template match="/" xml:id="id_11">
              <nstrgmpr:executeResponse xml:id="id_12">
                    <ns19:response-wrapper xml:id="id_31">
                          <ns19:output xml:id="id_32">
                                <ns19:inventories xml:id="id_33">
                                      <ns19:items xml:id="id_34">
                                            <ns19:inventoryType xml:id="id_119">
                                                  <xsl:value-of xml:id="id_120" select="dvm:lookupValue (&quot;WAMOFSC_ConfigProps&quot;, &quot;PropertyName&quot;, &quot;asset.inventory.type&quot;, &quot;Value&quot;, &quot;asset.inventory.type.error&quot; )"/>
                                            </ns19:inventoryType>
                                            <xsl:choose xml:id="id_50">
                                                  <xsl:when xml:id="id_51" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetId">
                                                        <ns19:serialNumber xml:id="id_35">
                                                              <xsl:value-of xml:id="id_53" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetId"/>
                                                        </ns19:serialNumber>
                                                  </xsl:when>
                                                  <xsl:otherwise xml:id="id_54">
                                                        <ns19:serialNumber xml:id="id_359">
                                                              <xsl:value-of xml:id="id_57" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:nodeId"/>
                                                        </ns19:serialNumber>
                                                  </xsl:otherwise>
                                            </xsl:choose>
                                            <xsl:if xml:id="id_200" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:validMeasurementTypes">
                                                  <ns19:wam_valid_measurement_types xml:id="id_154">
                                                        <xsl:value-of xml:id="id_155" select="oraext:get-content-as-string ($AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:validMeasurementTypes )"/>
                                                  </ns19:wam_valid_measurement_types>
                                            </xsl:if>
                                            <xsl:if xml:id="id_287" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:serialNo">
                                                  <ns19:ITEM_NUMBER xml:id="id_71">
                                                        <xsl:value-of xml:id="id_72" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:serialNo"/>
                                                  </ns19:ITEM_NUMBER>
                                            </xsl:if>
                                            <xsl:if xml:id="id_284" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:nodeId">
                                                  <ns19:wam_node_id xml:id="id_73">
                                                        <xsl:value-of xml:id="id_74" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:nodeId"/>
                                                  </ns19:wam_node_id>
                                            </xsl:if>
                                            <xsl:if xml:id="id_281" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:attachedToAssetId">
                                                  <ns19:wam_attached_to_asset_id xml:id="id_75">
                                                        <xsl:value-of xml:id="id_76" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:attachedToAssetId"/>
                                                  </ns19:wam_attached_to_asset_id>
                                            </xsl:if>
                                            <xsl:if xml:id="id_278" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:maybeLeftInPlace">
                                                  <ns19:wam_asset_maybeLeftInPlace xml:id="id_77">
                                                        <xsl:value-of xml:id="id_78" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:maybeLeftInPlace"/>
                                                  </ns19:wam_asset_maybeLeftInPlace>
                                            </xsl:if>
                                            <xsl:if xml:id="id_275" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:info">
                                                  <ns19:wam_asset_info xml:id="id_79">
                                                        <xsl:value-of xml:id="id_80" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:info"/>
                                                  </ns19:wam_asset_info>
                                            </xsl:if>
                                            <xsl:if xml:id="id_214" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:badgeNo">
                                                  <ns19:wam_badge_number xml:id="id_81">
                                                        <xsl:value-of xml:id="id_138" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:badgeNo"/>
                                                  </ns19:wam_badge_number>
                                            </xsl:if>
                                            <xsl:if xml:id="id_217" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:validServiceHistoryTypes">
                                                  <ns19:wam_asset_valid_service_history_types>
                                                        <xsl:value-of xml:id="id_140" select="oraext:get-content-as-string ($AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:validServiceHistoryTypes )"/>
                                                  </ns19:wam_asset_valid_service_history_types>
                                            </xsl:if>
                                            <xsl:if xml:id="id_220" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:failureInformation">
                                                  <ns19:wam_failure_info xml:id="id_185">
                                                        <xsl:value-of xml:id="id_186" select="oraext:get-content-as-string ($AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:failureInformation )"/>
                                                  </ns19:wam_failure_info>
                                            </xsl:if>
                                            <xsl:if xml:id="id_223" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:info">
                                                  <ns19:wam_asset_location_info xml:id="id_91">
                                                        <xsl:value-of xml:id="id_129" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:info"/>
                                                  </ns19:wam_asset_location_info>
                                            </xsl:if>
                                            <xsl:if xml:id="id_226" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:building">
                                                  <ns19:wam_asset_location_building xml:id="id_93">
                                                        <xsl:value-of xml:id="id_94" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:building"/>
                                                  </ns19:wam_asset_location_building>
                                            </xsl:if>
                                            <xsl:if xml:id="id_229" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:room">
                                                  <ns19:wam_asset_location_room xml:id="id_95">
                                                        <xsl:value-of xml:id="id_96" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:room"/>
                                                  </ns19:wam_asset_location_room>
                                            </xsl:if>
                                            <xsl:if xml:id="id_232" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:runToFailure">
                                                  <ns19:wam_asset_location_runToFailure xml:id="id_97">
                                                        <xsl:value-of xml:id="id_98" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:runToFailure"/>
                                                  </ns19:wam_asset_location_runToFailure>
                                            </xsl:if>
                                            <xsl:if xml:id="id_235" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:siteLocation">
                                                  <ns19:wam_asset_location_siteLocation xml:id="id_99">
                                                        <xsl:value-of xml:id="id_100" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:siteLocation"/>
                                                  </ns19:wam_asset_location_siteLocation>
                                            </xsl:if>
                                            <xsl:if xml:id="id_238" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:pointId">
                                                  <ns19:wam_asset_location_pointId xml:id="id_101">
                                                        <xsl:value-of xml:id="id_102" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:pointId"/>
                                                  </ns19:wam_asset_location_pointId>
                                            </xsl:if>
                                            <xsl:if xml:id="id_252" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:serviceArea">
                                                  <ns19:wam_asset_location_serviceArea xml:id="id_103">
                                                        <xsl:value-of xml:id="id_104" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:serviceArea"/>
                                                  </ns19:wam_asset_location_serviceArea>
                                            </xsl:if>
											<ns19:wam_is_asset_location>
												<xsl:value-of select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:locationInformation/ns28:isAssetLocation"/>
											</ns19:wam_is_asset_location>
                                            <xsl:if xml:id="id_255" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetId">
                                                  <ns19:wam_asset_id xml:id="id_105">
                                                        <xsl:value-of xml:id="id_171" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetId"/>
                                                  </ns19:wam_asset_id>
                                            </xsl:if>
                                            <xsl:if xml:id="id_258" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:validMeasurementTypes/ns28:measurementTypeList/ns28:description">
                                                  <ns19:wam_asset_desc xml:id="id_107">
                                                        <xsl:value-of xml:id="id_108" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:validMeasurementTypes/ns28:measurementTypeList/ns28:description"/>
                                                  </ns19:wam_asset_desc>
                                            </xsl:if>
                                            <xsl:if xml:id="id_261" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:assetType">
                                                  <ns19:wam_asset_type xml:id="id_109">
                                                        <xsl:value-of xml:id="id_110" select="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:assetType"/>
                                                  </ns19:wam_asset_type>
                                            </xsl:if>
											<ns19:wam_asset_or_component>
											<xsl:choose>
												<xsl:when test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:assetLocationAssets/ns28:assetLocationAssetList/ns28:assetDetails/ns28:isComponent='W1YS'">
														<xsl:value-of select="'C'"/>
												</xsl:when>
												<xsl:otherwise>
													<xsl:value-of select="'A'"/>
												</xsl:otherwise>
											</xsl:choose>
											</ns19:wam_asset_or_component>								   
                                            <ns19:wam_asset_worked xml:id="id_156">
                                                  <xsl:value-of xml:id="id_157" select="1"/>
                                            </ns19:wam_asset_worked>
                                      </ns19:items>
                                </ns19:inventories>
                                <xsl:if xml:id="id_26001" test="$AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:serviceHistoryTypes">
                                      <xsl:variable name="wamSHTStr">
                                            <xsl:value-of select="oraext:get-content-as-string($AssetQuery/nsmpr0:W1GAstDtlBNoResponse/ns28:W1GAstDtlBNo/ns28:output/ns28:serviceHistoryTypes )"/>
                                      </xsl:variable>
                                      <xsl:variable name="msgSize">
                                            <xsl:value-of select="string-length($wamSHTStr)"/>
                                      </xsl:variable>
                                      <xsl:variable name="sizeInKB">
                                            <xsl:value-of select="$msgSize div 1024"/>
                                      </xsl:variable>
                                      <xsl:variable name="sht_node">
                                            <xsl:call-template name="splitWAM_SHT">
                                                  <xsl:with-param name="wam_SHT_ip" select="$wamSHTStr"/>
                                            </xsl:call-template>
                                      </xsl:variable>
                                      <xsl:if test="$sht_node/sht_text[1]">
                                            <ns19:wam_service_history_types1>
                                                  <xsl:value-of select="$sht_node/sht_text[1]"/>
                                            </ns19:wam_service_history_types1>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[2]">
                                            <ns19:wam_service_history_types2>
                                                  <xsl:value-of select="$sht_node/sht_text[2]"/>
                                            </ns19:wam_service_history_types2>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[3]">
                                            <ns19:wam_service_history_types3>
                                                  <xsl:value-of select="$sht_node/sht_text[3]"/>
                                            </ns19:wam_service_history_types3>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[4]">
                                            <ns19:wam_service_history_types4>
                                                  <xsl:value-of select="$sht_node/sht_text[4]"/>
                                            </ns19:wam_service_history_types4>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[5]">
                                            <ns19:wam_service_history_types5>
                                                  <xsl:value-of select="$sht_node/sht_text[5]"/>
                                            </ns19:wam_service_history_types5>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[6]">
                                            <ns19:wam_service_history_types6>
                                                  <xsl:value-of select="$sht_node/sht_text[6]"/>
                                            </ns19:wam_service_history_types6>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[7]">
                                            <ns19:wam_service_history_types7>
                                                  <xsl:value-of select="$sht_node/sht_text[7]"/>
                                            </ns19:wam_service_history_types7>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[8]">
                                            <ns19:wam_service_history_types8>
                                                  <xsl:value-of select="$sht_node/sht_text[8]"/>
                                            </ns19:wam_service_history_types8>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[9]">
                                            <ns19:wam_service_history_types9>
                                                  <xsl:value-of select="$sht_node/sht_text[9]"/>
                                            </ns19:wam_service_history_types9>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[10]">
                                            <ns19:wam_service_history_types10>
                                                  <xsl:value-of select="$sht_node/sht_text[10]"/>
                                            </ns19:wam_service_history_types10>
                                      </xsl:if>
                                </xsl:if>
                          </ns19:output>
                    </ns19:response-wrapper>
              </nstrgmpr:executeResponse>
        </xsl:template>
        <xsl:template name="splitWAM_SHT">
              <xsl:param name="wam_SHT_ip"/>
              <xsl:choose>
                    <xsl:when test="string-length($wam_SHT_ip) &lt; 65536">
                          <sht_text>
                                <xsl:value-of select="$wam_SHT_ip"/>
                          </sht_text>
                    </xsl:when>
                    <xsl:when test="string-length($wam_SHT_ip) > 65535">
                          <sht_text>
                                <xsl:value-of select="substring($wam_SHT_ip,0,65535)"/>
                          </sht_text>
                          <xsl:call-template name="splitWAM_SHT">
                                <xsl:with-param name="wam_SHT_ip" select="substring($wam_SHT_ip, 65536, string-length($wam_SHT_ip)-65535)"/>
                          </xsl:call-template>
                    </xsl:when>
              </xsl:choose>
        </xsl:template>
  </xsl:stylesheet>