<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:nstrgmpr="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryDetailsPickup/types" xmlns:ns5="http://xmlns.oracle.com/cloud/generic/rest/fault/REST/receiveRequest/assetQueryDetailsPickup" xmlns:ns0="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:nstrgdfl="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest/assetQueryDetailsPickup/types" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:ns1="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns2="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy/fault/types" xmlns:ns4="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryDetailsPickup" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:nsmpr0="http://xmlns.oracle.com/cloud/adapter/oracleutilities/GetAssetDetailsForPickup_REQUEST/types" xmlns:nsmpr1="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:orajs11="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1667070767" xmlns:nxsd="http://xmlns.oracle.com/pcbpel/nxsd" xmlns:plnk="http://schemas.xmlsoap.org/ws/2003/05/partner-link/" xmlns:orajs14="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath948039040" xmlns:orajs4="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1681625448" xmlns:orajs0="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath56919032" xmlns:orajs7="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath123170385" xmlns:orajs2="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1396154174" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:orajs10="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1429540732" xmlns:ns31="http://xmlns.oracle.com/cloud/adapter/oracleutilities/GetAssetDetailsForPickup_REQUEST" xmlns:ns24="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryDetailsPickup/request/types" xmlns:orajs12="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath877648652" xmlns:orajs8="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath761874789" xmlns:wssutil="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:orajs9="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath673895125" xmlns:orajs1="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1635443809" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.dvm.DVMFunctions" xmlns:ns26="http://ouaf.oracle.com/webservices/w1/W1-GetAssetLocationDetails" xmlns:ouaf="http://ouaf.oracle.com/" xmlns:orajs3="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1596616741" xmlns:orajs15="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath86288" xmlns:wsp="http://www.w3.org/ns/ws-policy" xmlns:ns6="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:orajs13="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1673207123" xmlns:ns3="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:orajs5="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1634410945" xmlns:ns23="http://xmlns.oracle.com/procmon" xmlns:ns25="http://xmlns.oracle.com/ics/tracking/ics_tracking_context.xsd" xmlns:orajs6="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1468259163" version="2.0" xml:id="id_1" exclude-result-prefixes=" oraext xsd xp20 ora oracle-xsl-mapper xsi fn xsl ignore01" ignore01:ignorexmlids="true" xmlns:xml="http://www.w3.org/XML/1998/namespace">
        <oracle-xsl-mapper:schema xml:id="id_2">
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources xml:id="id_3">
                    <oracle-xsl-mapper:source type="WSDL" xml:id="id_4">
                          <oracle-xsl-mapper:schema location="../../application_855/outbound_856/resourcegroup_857/receiveRequest_assetQueryDetailsPickup_REQUEST.wsdl" xml:id="id_5"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryDetailsPickup/types" xml:id="id_6"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL" xml:id="id_13">
                          <oracle-xsl-mapper:schema location="../../application_1268/inbound_1269/resourcegroup_1270/GetAssetDetailsForPickup_REQUEST.wsdl" xml:id="id_14"/>
                          <oracle-xsl-mapper:rootElement name="W1-GetAstDtlResponse" namespace="http://xmlns.oracle.com/cloud/adapter/oracleutilities/GetAssetDetailsForPickup_REQUEST/types" xml:id="id_15"/>
                          <oracle-xsl-mapper:param name="GetAssetDetailsForPickup" xml:id="id_16"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets xml:id="id_7">
                    <oracle-xsl-mapper:target type="WSDL" xml:id="id_8">
                          <oracle-xsl-mapper:schema location="../../application_855/outbound_856/resourcegroup_857/receiveRequest_assetQueryDetailsPickup_REQUEST.wsdl" xml:id="id_9"/>
                          <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryDetailsPickup/types" xml:id="id_10"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
              <!--GENERATED BY ORACLE XSL MAPPER 12.1.2.0.0-->
        </oracle-xsl-mapper:schema>
        <!--User Editing allowed BELOW this line - DO NOT DELETE THIS LINE-->
        <xsl:param name="GetAssetDetailsForPickup" xml:id="id_25"/>
        <xsl:template match="/" xml:id="id_11">
              <nstrgmpr:executeResponse xml:id="id_12">
                    <nstrgdfl:response-wrapper xml:id="id_31">
                          <nstrgdfl:output xml:id="id_32">
                                <nstrgdfl:inventories xml:id="id_33">
                                      <nstrgdfl:items xml:id="id_34">
                                            <nstrgdfl:inventoryType xml:id="id_74">
                                                  <xsl:value-of xml:id="id_75" select="dvm:lookupValue (&quot;WAMOFSC_ConfigProps&quot;, &quot;PropertyName&quot;, &quot;asset.inventory.type&quot;, &quot;Value&quot;, &quot;asset.inventory.type.error&quot; )"/>
                                            </nstrgdfl:inventoryType>
                                            <nstrgdfl:serialNumber xml:id="id_76">
                                                  <xsl:value-of xml:id="id_77" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetId"/>
                                            </nstrgdfl:serialNumber>
                                            <xsl:if xml:id="id_80" test="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:validMeasurementTypes">
                                                  <nstrgdfl:wam_valid_measurement_types xml:id="id_81">
                                                        <xsl:value-of xml:id="id_82" select="oraext:get-content-as-string ($GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:validMeasurementTypes )"/>
                                                  </nstrgdfl:wam_valid_measurement_types>
                                            </xsl:if>
                                            <nstrgdfl:ITEM_NUMBER xml:id="id_83">
                                                  <xsl:value-of xml:id="id_84" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetDetails/ns26:serialNo"/>
                                            </nstrgdfl:ITEM_NUMBER>
                                            <nstrgdfl:wam_node_id xml:id="id_37">
                                                  <xsl:value-of xml:id="id_38" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:nodeId"/>
                                            </nstrgdfl:wam_node_id>
                                            <nstrgdfl:wam_attached_to_asset_id xml:id="id_53">
                                                  <xsl:value-of xml:id="id_54" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetDetails/ns26:attachedToAssetId"/>
                                            </nstrgdfl:wam_attached_to_asset_id>
                                            <nstrgdfl:wam_asset_maybeLeftInPlace xml:id="id_55">
                                                  <xsl:value-of xml:id="id_56" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetDetails/ns26:maybeLeftInPlace"/>
                                            </nstrgdfl:wam_asset_maybeLeftInPlace>
                                            <nstrgdfl:wam_asset_info xml:id="id_51">
                                                  <xsl:value-of xml:id="id_52" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetDetails/ns26:info"/>
                                            </nstrgdfl:wam_asset_info>
                                            <nstrgdfl:wam_badge_number xml:id="id_35">
                                                  <xsl:value-of xml:id="id_36" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:badgeNo"/>
                                            </nstrgdfl:wam_badge_number>
                                            <xsl:if xml:id="id_180" test="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:validServiceHistoryTypes">
                                                  <nstrgdfl:wam_asset_valid_service_history_types xml:id="id_85">
                                                        <xsl:value-of xml:id="id_86" select="oraext:get-content-as-string ($GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:validServiceHistoryTypes )"/>
                                                  </nstrgdfl:wam_asset_valid_service_history_types>
                                            </xsl:if>
                                            <xsl:if xml:id="id_1800" test="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:failureInformation">
                                                  <nstrgdfl:wam_failure_info xml:id="id_87">
                                                        <xsl:value-of xml:id="id_88" select="oraext:get-content-as-string ($GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:failureInformation )"/>
                                                  </nstrgdfl:wam_failure_info>
                                            </xsl:if>
                                            <nstrgdfl:wam_asset_location_info xml:id="id_49">
                                                  <xsl:value-of xml:id="id_50" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:info"/>
                                            </nstrgdfl:wam_asset_location_info>
                                            <nstrgdfl:wam_asset_location_building xml:id="id_41">
                                                  <xsl:value-of xml:id="id_42" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:building"/>
                                            </nstrgdfl:wam_asset_location_building>
                                            <nstrgdfl:wam_asset_location_room xml:id="id_43">
                                                  <xsl:value-of xml:id="id_44" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:room"/>
                                            </nstrgdfl:wam_asset_location_room>
                                            <xsl:if test="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:runToFailure">
                                            <nstrgdfl:wam_asset_location_runToFailure xml:id="id_89">
                                                  <xsl:value-of xml:id="id_90" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:runToFailure"/>
                                            </nstrgdfl:wam_asset_location_runToFailure>
                                            </xsl:if>
                                            <nstrgdfl:wam_asset_location_siteLocation xml:id="id_91">
                                                  <xsl:value-of xml:id="id_92" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:siteLocation"/>
                                            </nstrgdfl:wam_asset_location_siteLocation>
                                            <nstrgdfl:wam_asset_location_pointId xml:id="id_45">
                                                  <xsl:value-of xml:id="id_46" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:pointId"/>
                                            </nstrgdfl:wam_asset_location_pointId>
                                            <nstrgdfl:wam_asset_location_serviceArea xml:id="id_47">
                                                  <xsl:value-of xml:id="id_48" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:serviceArea"/>
                                            </nstrgdfl:wam_asset_location_serviceArea>
                                            <nstrgdfl:wam_is_asset_location>
                                                  <xsl:value-of select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:locationInformation/ns26:isAssetLocation"/>
                                            </nstrgdfl:wam_is_asset_location>
                                            <nstrgdfl:wam_asset_id xml:id="id_39">
                                                  <xsl:value-of xml:id="id_40" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetId"/>
                                            </nstrgdfl:wam_asset_id>
                                            <nstrgdfl:wam_asset_desc xml:id="id_57">
                                                  <xsl:value-of xml:id="id_58" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetDetails/ns26:description"/>
                                            </nstrgdfl:wam_asset_desc>
                                            <nstrgdfl:wam_asset_type xml:id="id_59">
                                                  <xsl:value-of xml:id="id_60" select="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetDetails/ns26:assetType"/>
                                            </nstrgdfl:wam_asset_type>
                                            <nstrgdfl:wam_asset_worked xml:id="id_93">
                                                  <xsl:value-of xml:id="id_94" select="&quot;1&quot;"/>
                                            </nstrgdfl:wam_asset_worked>
                                            <nstrgdfl:wam_asset_or_component>
                                                  <xsl:choose>
                                                        <xsl:when test="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:assetLocationAssets/ns26:assetLocationAssetList/ns26:assetDetails/ns26:isComponent='W1YS'">
                                                              <xsl:value-of select="'C'"/>
                                                        </xsl:when>
                                                        <xsl:otherwise>
                                                              <xsl:value-of select="'A'"/>
                                                        </xsl:otherwise>
                                                  </xsl:choose>
                                            </nstrgdfl:wam_asset_or_component>
                                      </nstrgdfl:items>
                                </nstrgdfl:inventories>
                                <xsl:if xml:id="id_26001" test="$GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:serviceHistoryTypes">
                                      <xsl:variable name="wamSHTStr">
                                            <xsl:value-of select="oraext:get-content-as-string($GetAssetDetailsForPickup/nsmpr0:W1-GetAstDtlResponse/ns26:W1-GetAstDtl/ns26:serviceHistoryTypes )"/>
                                      </xsl:variable>
                                      <xsl:variable name="msgSize">
                                            <xsl:value-of select="string-length($wamSHTStr)"/>
                                      </xsl:variable>
                                      <xsl:variable name="sizeInKB">
                                            <xsl:value-of select="$msgSize div 1024"/>
                                      </xsl:variable>
                                      <xsl:variable name="sht_node">
                                            <xsl:call-template name="splitWAM_SHT">
                                                  <xsl:with-param name="wam_SHT_ip" select="$wamSHTStr"/>
                                            </xsl:call-template>
                                      </xsl:variable>
                                      <xsl:if test="$sht_node/sht_text[1]">
                                            <nstrgdfl:wam_service_history_types1 xml:id="id_95">
                                                  <xsl:value-of select="$sht_node/sht_text[1]"/>
                                            </nstrgdfl:wam_service_history_types1>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[2]">
                                            <nstrgdfl:wam_service_history_types2>
                                                  <xsl:value-of select="$sht_node/sht_text[2]"/>
                                            </nstrgdfl:wam_service_history_types2>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[3]">
                                            <nstrgdfl:wam_service_history_types3>
                                                  <xsl:value-of select="$sht_node/sht_text[3]"/>
                                            </nstrgdfl:wam_service_history_types3>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[4]">
                                            <nstrgdfl:wam_service_history_types4>
                                                  <xsl:value-of select="$sht_node/sht_text[4]"/>
                                            </nstrgdfl:wam_service_history_types4>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[5]">
                                            <nstrgdfl:wam_service_history_types5>
                                                  <xsl:value-of select="$sht_node/sht_text[5]"/>
                                            </nstrgdfl:wam_service_history_types5>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[6]">
                                            <nstrgdfl:wam_service_history_types6>
                                                  <xsl:value-of select="$sht_node/sht_text[6]"/>
                                            </nstrgdfl:wam_service_history_types6>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[7]">
                                            <nstrgdfl:wam_service_history_types7>
                                                  <xsl:value-of select="$sht_node/sht_text[7]"/>
                                            </nstrgdfl:wam_service_history_types7>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[8]">
                                            <nstrgdfl:wam_service_history_types8>
                                                  <xsl:value-of select="$sht_node/sht_text[8]"/>
                                            </nstrgdfl:wam_service_history_types8>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[9]">
                                            <nstrgdfl:wam_service_history_types9>
                                                  <xsl:value-of select="$sht_node/sht_text[9]"/>
                                            </nstrgdfl:wam_service_history_types9>
                                      </xsl:if>
                                      <xsl:if test="$sht_node/sht_text[10]">
                                            <nstrgdfl:wam_service_history_types10>
                                                  <xsl:value-of select="$sht_node/sht_text[10]"/>
                                            </nstrgdfl:wam_service_history_types10>
                                      </xsl:if>
                                </xsl:if>
                          </nstrgdfl:output>
                    </nstrgdfl:response-wrapper>
              </nstrgmpr:executeResponse>
        </xsl:template>
        <xsl:template name="splitWAM_SHT">
              <xsl:param name="wam_SHT_ip"/>
              <xsl:choose>
                    <xsl:when test="string-length($wam_SHT_ip) &lt; 65536">
                          <sht_text>
                                <xsl:value-of select="$wam_SHT_ip"/>
                          </sht_text>
                    </xsl:when>
                    <xsl:when test="string-length($wam_SHT_ip) > 65535">
                          <sht_text>
                                <xsl:value-of select="substring($wam_SHT_ip,0,65535)"/>
                          </sht_text>
                          <xsl:call-template name="splitWAM_SHT">
                                <xsl:with-param name="wam_SHT_ip" select="substring($wam_SHT_ip, 65536, string-length($wam_SHT_ip)-65535)"/>
                          </xsl:call-template>
                    </xsl:when>
              </xsl:choose>
        </xsl:template>
  </xsl:stylesheet>