<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xml:id="id_1" xmlns:ns0="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:plnk="http://schemas.xmlsoap.org/ws/2003/05/partner-link/" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:ns5="http://xmlns.oracle.com/cloud/generic/rest/fault/REST/receiveRequest/assetQueryForPickup" xmlns:ns1="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:ns4="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryForPickup" xmlns:nstrgdfl="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest/assetQueryForPickup/types" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:nstrgmpr="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryForPickup/types" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ns2="http://xmlns.oracle.com/cloud/adapter/internal/commons/proxy/fault/types" exclude-result-prefixes=" oraext xsd xp20 ora oracle-xsl-mapper xsi fn xsl ignore01" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" ignore01:ignorexmlids="true" xmlns:nsmpr0="http://xmlns.oracle.com/cloud/adapter/oracleutilities/MainAssetQueryForPickup_REQUEST/types" xmlns:nsmpr1="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:xml="http://www.w3.org/XML/1998/namespace" xmlns:orajs1="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1635443809" xmlns:orajs11="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1667070767" xmlns:ns28="http://xmlns.oracle.com/cloud/adapter/oracleutilities/MainAssetQueryForPickup_REQUEST" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.dvm.DVMFunctions" xmlns:orajs14="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath948039040" xmlns:orajs4="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1681625448" xmlns:orajs0="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath56919032" xmlns:orajs6="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath123170385" xmlns:ns22="http://xml.oracle.com/adapters/extension" xmlns:orajs2="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1396154174" xmlns:ns23="http://ouaf.oracle.com/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:orajs10="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1429540732" xmlns:orajs3="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1596616741" xmlns:ns29="http://ouaf.oracle.com/webservices/w1/W1-AssetQuery" xmlns:tns="http://ouaf.oracle.com/webservices/w1/W1GAstDtlBNo" xmlns:orajs15="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath86288" xmlns:wsp="http://www.w3.org/ns/ws-policy" xmlns:ns6="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:orajs12="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath877648652" xmlns:orajs8="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath761874789" xmlns:orajs13="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1673207123" xmlns:ns3="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:orajs5="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1634410945" xmlns:wssutil="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:orajs9="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath673895125" xmlns:orajs7="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1468259163">
   <oracle-xsl-mapper:schema xml:id="id_2">
      <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
      <oracle-xsl-mapper:mapSources xml:id="id_3">
         <oracle-xsl-mapper:source type="WSDL" xml:id="id_4">
            <oracle-xsl-mapper:schema location="../../application_815/outbound_816/resourcegroup_817/receiveRequest_assetQueryForPickup_REQUEST.wsdl" xml:id="id_5"/>
            <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryForPickup/types" xml:id="id_6"/>
         </oracle-xsl-mapper:source>
         <oracle-xsl-mapper:source type="WSDL" xml:id="id_13">
            <oracle-xsl-mapper:schema location="../../application_1164/inbound_1165/resourcegroup_1166/MainAssetQueryForPickup_REQUEST.wsdl" xml:id="id_14"/>
            <oracle-xsl-mapper:rootElement name="W1-AssetQueryResponse" namespace="http://xmlns.oracle.com/cloud/adapter/oracleutilities/MainAssetQueryForPickup_REQUEST/types" xml:id="id_15"/>
            <oracle-xsl-mapper:param name="MainAssetQueryForPickup" xml:id="id_16"/>
         </oracle-xsl-mapper:source>
      </oracle-xsl-mapper:mapSources>
      <oracle-xsl-mapper:mapTargets xml:id="id_7">
         <oracle-xsl-mapper:target type="WSDL" xml:id="id_8">
            <oracle-xsl-mapper:schema location="../../application_815/outbound_816/resourcegroup_817/receiveRequest_assetQueryForPickup_REQUEST.wsdl" xml:id="id_9"/>
            <oracle-xsl-mapper:rootElement name="executeResponse" namespace="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/assetQueryForPickup/types" xml:id="id_10"/>
         </oracle-xsl-mapper:target>
      </oracle-xsl-mapper:mapTargets>
      <!--GENERATED BY ORACLE XSL MAPPER 12.1.2.0.0-->
   </oracle-xsl-mapper:schema>
   <!--User Editing allowed BELOW this line - DO NOT DELETE THIS LINE-->
   <xsl:param name="MainAssetQueryForPickup" xml:id="id_25"/>
   <xsl:template match="/" xml:id="id_11">
      <nstrgmpr:executeResponse xml:id="id_12">
         <nstrgdfl:response-wrapper xml:id="id_31">
            <nstrgdfl:output xml:id="id_32">
               <xsl:for-each xml:id="id_34" select="$MainAssetQueryForPickup/nsmpr0:W1-AssetQueryResponse/ns29:W1-AssetQuery/ns29:output/ns29:assets/ns29:assetList">
                  <nstrgdfl:assetList xml:id="id_35">
                     <nstrgdfl:assetId xml:id="id_36">
                        <xsl:value-of xml:id="id_37" select="ns29:assetId"/>
                     </nstrgdfl:assetId>
                     <nstrgdfl:assetInfo xml:id="id_38">
                        <xsl:value-of xml:id="id_39" select="ns29:assetInfo"/>
                     </nstrgdfl:assetInfo>
                     <nstrgdfl:nodeId xml:id="id_40">
                        <xsl:value-of xml:id="id_41" select="ns29:nodeId"/>
                     </nstrgdfl:nodeId>
                     <nstrgdfl:locationInfo xml:id="id_42">
                        <xsl:value-of xml:id="id_43" select="ns29:locationInfo"/>
                     </nstrgdfl:locationInfo>
                  </nstrgdfl:assetList>
               </xsl:for-each>
            </nstrgdfl:output>
         </nstrgdfl:response-wrapper>
      </nstrgmpr:executeResponse>
   </xsl:template>
</xsl:stylesheet>