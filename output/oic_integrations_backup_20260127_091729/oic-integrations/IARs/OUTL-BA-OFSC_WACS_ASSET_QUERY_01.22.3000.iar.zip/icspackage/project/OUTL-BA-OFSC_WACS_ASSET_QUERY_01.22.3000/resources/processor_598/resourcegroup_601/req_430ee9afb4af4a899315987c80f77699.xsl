<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xml:id="id_1" xmlns:nstrgmpr="http://xmlns.oracle.com/cloud/adapter/Oracle_Utilities/AssetQuery_REQUEST/types" xmlns:ns1="http://xmlns.oracle.com/cloud/adapter/Oracle_Utilities/AssetQuery_REQUEST" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:plnk="http://schemas.xmlsoap.org/ws/2003/05/partner-link/" xmlns:wsp="http://www.w3.org/ns/ws-policy" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ns2="http://xmlns.oracle.com/cloud/generic/rest/fault/REST/receiveRequest" xmlns:ns12="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST" xmlns:wsdl="http://schemas.xmlsoap.org/wsdl/" xmlns:tns="http://ouaf.oracle.com/webservices/w1/W1-ExtMobileControlData" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:nssrcdfl="http://xmlns.oracle.com/procmon" xmlns:wssutil="http://docs.oasis-open.org/wss/2004/01/oasis-200401-wss-wssecurity-utility-1.0.xsd" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ouaf="http://ouaf.oracle.com/" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:nssrcmpr="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/types" exclude-result-prefixes=" oraext plnk xsd xp20 ns2 ns12 ora oracle-xsl-mapper nssrcdfl xsi fn xsl nssrcmpr ignore01" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" ignore01:ignorexmlids="true" xmlns:nsmpr0="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:xml="http://www.w3.org/XML/1998/namespace" xmlns:orajs12="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1667070767" xmlns:nxsd="http://xmlns.oracle.com/pcbpel/nxsd" xmlns:orajs15="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath948039040" xmlns:orajs16="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1473769253" xmlns:orajs17="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath182620986" xmlns:orajs4="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1681625448" xmlns:orajs0="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath56919032" xmlns:orajs7="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath123170385" xmlns:orajs2="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1396154174" xmlns:orajs11="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1429540732" xmlns:orajs8="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1789345403" xmlns:orajs13="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath877648652" xmlns:orajs9="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath761874789" xmlns:orajs18="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath709423846" xmlns:orajs19="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath372635089" xmlns:orajs10="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath673895125" xmlns:orajs1="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1635443809" xmlns:dvm="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.functions.dvm.DVMFunctions" xmlns:ns25="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest/types" xmlns:orajs3="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1596616741" xmlns:ns28="http://ouaf.oracle.com/webservices/w1/W1GAstDtlBNo" xmlns:ns3="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:orajs14="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1673207123" xmlns:ns0="http://www.oracle.com/XSL/Transform/java/oracle.tip.dvm.LookupValue" xmlns:orajs5="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1634410945" xmlns:ns27="http://xmlns.oracle.com/ics/tracking/ics_tracking_context.xsd" xmlns:orajs6="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath1468259163">
   <oracle-xsl-mapper:schema xml:id="id_2">
      <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
      <oracle-xsl-mapper:mapSources xml:id="id_3">
         <oracle-xsl-mapper:source type="WSDL" xml:id="id_4">
            <oracle-xsl-mapper:schema location="../../application_8/outbound_9/resourcegroup_10/receiveRequest_REQUEST.wsdl" xml:id="id_5"/>
            <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/receiveRequest_REQUEST/types" xml:id="id_6"/>
         </oracle-xsl-mapper:source>
      </oracle-xsl-mapper:mapSources>
      <oracle-xsl-mapper:mapTargets xml:id="id_7">
         <oracle-xsl-mapper:target type="WSDL" xml:id="id_8">
            <oracle-xsl-mapper:schema location="../../application_586/inbound_587/resourcegroup_588/AssetQuery_REQUEST.wsdl" xml:id="id_9"/>
            <oracle-xsl-mapper:rootElement name="W1GAstDtlBNo" namespace="http://xmlns.oracle.com/cloud/adapter/Oracle_Utilities/AssetQuery_REQUEST/types" xml:id="id_10"/>
         </oracle-xsl-mapper:target>
      </oracle-xsl-mapper:mapTargets>
      <!--GENERATED BY ORACLE XSL MAPPER 12.1.2.0.0-->
   </oracle-xsl-mapper:schema>
   <!--User Editing allowed BELOW this line - DO NOT DELETE THIS LINE-->
   <xsl:template match="/" xml:id="id_11">
      <nstrgmpr:W1GAstDtlBNo xml:id="id_12">
         <ns28:W1GAstDtlBNo xml:id="id_21">
            <ns28:input xml:id="id_22">
               <ns28:activityId xml:id="id_23">
                  <xsl:value-of xml:id="id_24" select="/nssrcmpr:execute/ns25:request-wrapper/ns25:activityId"/>
               </ns28:activityId>
               <ns28:badgeNo xml:id="id_25">
                  <xsl:value-of xml:id="id_26" select="/nssrcmpr:execute/ns25:request-wrapper/ns25:badgeNo"/>
               </ns28:badgeNo>
               <ns28:nodeId xml:id="id_27">
                  <xsl:value-of xml:id="id_28" select="/nssrcmpr:execute/ns25:request-wrapper/ns25:nodeId"/>
               </ns28:nodeId>
               <xsl:if xml:id="id_36" test="/nssrcmpr:execute/ns25:request-wrapper/ns25:attachedToAssetId">
                  <ns28:attachedToAssetId xml:id="id_29">
                     <xsl:value-of xml:id="id_30" select="/nssrcmpr:execute/ns25:request-wrapper/ns25:attachedToAssetId"/>
                  </ns28:attachedToAssetId>
               </xsl:if>
               <xsl:if xml:id="id_33" test="/nssrcmpr:execute/ns25:request-wrapper/ns25:attachToAssetId">
                  <ns28:attachToAssetId xml:id="id_34">
                     <xsl:value-of xml:id="id_35" select="/nssrcmpr:execute/ns25:request-wrapper/ns25:attachToAssetId"/>
                  </ns28:attachToAssetId>
               </xsl:if>
            </ns28:input>
         </ns28:W1GAstDtlBNo>
      </nstrgmpr:W1GAstDtlBNo>
   </xsl:template>
</xsl:stylesheet>