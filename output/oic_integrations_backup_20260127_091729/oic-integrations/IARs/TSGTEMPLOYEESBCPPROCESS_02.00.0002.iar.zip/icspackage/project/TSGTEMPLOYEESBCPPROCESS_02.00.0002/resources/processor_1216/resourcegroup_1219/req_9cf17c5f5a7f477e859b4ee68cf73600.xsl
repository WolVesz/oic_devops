<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:tns="urn:enterprise.soap.sforce.com" xmlns:ctar="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateTermination_REQUEST" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:soap="http://schemas.xmlsoap.org/wsdl/soap/" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:stgfr="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadTerminationFile_REQUEST/types" xmlns:stgf="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadTerminationFile" version="2.0" exclude-result-prefixes=" oraext plnk xsd xp20 ns9 ora oracle-xsl-mapper nssrcmpr nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_869/resourcegroup_872/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="bulkResponse" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/CompleteJob_REQUEST"/>
                          <oracle-xsl-mapper:param name="CompleteResponse"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1571/inbound_1572/resourcegroup_1573/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_445/resourcegroup_448/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="bulkResponse" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateContacts_REQUEST"/>
                          <oracle-xsl-mapper:param name="ContactsJob"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_812/resourcegroup_815/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="batchInfoList" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/GetStatus_REQUEST"/>
                          <oracle-xsl-mapper:param name="JobStatus"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFileResponse" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_1496/resourcegroup_1497/ReadTerminationFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadTerminationFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadTerminationFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_1249/resourcegroup_1252/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="bulkResponse" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateTermination_REQUEST"/>
                          <oracle-xsl-mapper:param name="TerminationJob"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_222/resourcegroup_223/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1206/inbound_1207/resourcegroup_1208/UpdateTermination_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="upsert" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateTermination_REQUEST"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="CompleteResponse"/>
	<xsl:param name="Configs"/>
	<xsl:param name="ContactsJob"/>
	<xsl:param name="InProgress"/>
	<xsl:param name="IsEmpty"/>
	<xsl:param name="JobStatus"/>
	<xsl:param name="ReadExtract"/>
	<xsl:param name="ReadExtract_REQUEST"/>
	<xsl:param name="ReadTerminationFile"/>
	<xsl:param name="TerminationJob"/>
	<xsl:param name="WriteFile"/>
	<xsl:param name="WriteFile_REQUEST"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>

	<xsl:template match="/">
		<ctar:upsert>
			<ctar:FF__Key_Contact__cs>
				<xsl:for-each select="$ReadTerminationFile/stgfr:ReadResponse/stgf:DATA_DS/stgf:G_1/stgf:G_2/stgf:FILE_FRAGMENT/stgf:Employee_Feed_V2/stgf:Assigment">
			
				  <ctar:FF__Key_Contact__c>
						<ctar:externalIDFieldName>Employee_ID__c</ctar:externalIDFieldName>
						
						<ctar:City__c>
							  <xsl:value-of select="./stgf:Person/stgf:Person/stgf:Person/stgf:City"/>
						</ctar:City__c>
						<ctar:Employee_ID__c>
							<xsl:value-of select="./stgf:Person/stgf:Person/stgf:Person/stgf:PersonNumber"/>
						</ctar:Employee_ID__c>
						<ctar:FF__Company_Organization__c>
							<xsl:choose>
								<xsl:when test="./stgf:Assignment/stgf:AssignmentType = 'E'">
									<xsl:value-of select="./stgf:Assignment/stgf:Department"/>
								</xsl:when>
								<xsl:when test="./stgf:Assignment/stgf:AssignmentType = 'C'">Contractors</xsl:when>
							</xsl:choose>
						</ctar:FF__Company_Organization__c>
						<ctar:FF__First_Name__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:KnownAs)))">
									<xsl:value-of select="./stgf:Person/stgf:Person/stgf:Person/stgf:KnownAs"/>
								</xsl:when>
								<xsl:otherwise>
									<xsl:value-of select="./stgf:Person/stgf:Person/stgf:Person/stgf:FirstName"/>
								</xsl:otherwise>
							</xsl:choose>
						</ctar:FF__First_Name__c>
						<ctar:FF__Last_Name__c>
							<xsl:value-of select="./stgf:Person/stgf:Person/stgf:Person/stgf:LastName"/>
						</ctar:FF__Last_Name__c>
						<ctar:FF__Mobile_Phone__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:MPhoneAreaCode))) and boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:MPhone)))">
									<xsl:value-of select="concat(./stgf:Person/stgf:Person/stgf:Person/stgf:MPhoneAreaCode,'-',./stgf:Person/stgf:Person/stgf:Person/stgf:MPhone)"/>
								</xsl:when>
							</xsl:choose>
						</ctar:FF__Mobile_Phone__c>
						<ctar:FF__Phone__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:WPhoneAreaCode))) and boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:WPhone)))">
									<xsl:value-of select="concat(./stgf:Person/stgf:Person/stgf:Person/stgf:WPhoneAreaCode,'-',./stgf:Person/stgf:Person/stgf:Person/stgf:WPhone)"/>
								</xsl:when>
							</xsl:choose>
						</ctar:FF__Phone__c>
						<ctar:FF__Title__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Assignment/stgf:Job_Name)))">
									<xsl:value-of select="./stgf:Assignment/stgf:Job_Name"/>
								</xsl:when>
							</xsl:choose>
						</ctar:FF__Title__c>
						<ctar:Home_Phone__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:HPhoneAreaCode))) and boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:HPhone)))">
									<xsl:value-of select="concat(./stgf:Person/stgf:Person/stgf:Person/stgf:HPhoneAreaCode,'-',./stgf:Person/stgf:Person/stgf:Person/stgf:HPhone)"/>
								</xsl:when>
							</xsl:choose>
						</ctar:Home_Phone__c>
						<ctar:State__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:State)))">
									<xsl:value-of select="./stgf:Person/stgf:Person/stgf:Person/stgf:State"/>
								</xsl:when>
							</xsl:choose>
						</ctar:State__c>
						<ctar:Personal_Mobile_Phone__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:HMPhoneAreaCode))) and boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:HMPhone)))">
									<xsl:value-of select="concat(./stgf:Person/stgf:Person/stgf:Person/stgf:HMPhoneAreaCode,'-',./stgf:Person/stgf:Person/stgf:Person/stgf:HMPhone)"/>
								</xsl:when>
							</xsl:choose>
						</ctar:Personal_Mobile_Phone__c>
						<ctar:Work_Location__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Assignment/stgf:Location)))">
									<xsl:value-of select="./stgf:Assignment/stgf:Location"/>
								</xsl:when>
							</xsl:choose>
						</ctar:Work_Location__c>
						<ctar:User_Status__c>Terminated Assignment</ctar:User_Status__c>
						<ctar:Zip_Code__c>
							<xsl:choose>
								<xsl:when test="boolean(normalize-space(string(./stgf:Person/stgf:Person/stgf:Person/stgf:PostalCode)))">
									<xsl:value-of select="./stgf:Person/stgf:Person/stgf:Person/stgf:PostalCode"/>
								</xsl:when>
							</xsl:choose>
						</ctar:Zip_Code__c>
					</ctar:FF__Key_Contact__c>
				</xsl:for-each>
			</ctar:FF__Key_Contact__cs>
		</ctar:upsert>
	</xsl:template>	
	
</xsl:stylesheet>