<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:cjr="http://xmlns.oracle.com/cloud/adapter/salesforce/CompleteJob_REQUEST" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:rqr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types" xmlns:rq="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:tns="urn:enterprise.soap.sforce.com" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:uc="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateContacts_REQUEST" xmlns:ut="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateTermination_REQUEST" version="2.0" exclude-result-prefixes=" oraext plnk xsd xp20 ns9 ora oracle-xsl-mapper nssrcmpr nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">

         <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_869/resourcegroup_872/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="bulkResponse" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/CompleteJob_REQUEST"/>
                          <oracle-xsl-mapper:param name="CompleteResponse"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_1571/inbound_1572/resourcegroup_1573/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_445/resourcegroup_448/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="bulkResponse" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateContacts_REQUEST"/>
                          <oracle-xsl-mapper:param name="ContactsJob"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_812/resourcegroup_815/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="batchInfoList" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/GetStatus_REQUEST"/>
                          <oracle-xsl-mapper:param name="JobStatus"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFileResponse" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_1249/resourcegroup_1252/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="bulkResponse" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateTermination_REQUEST"/>
                          <oracle-xsl-mapper:param name="TerminationJob"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_222/resourcegroup_223/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_402/inbound_403/resourcegroup_404/CompleteJob_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="finalBatch" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/CompleteJob_REQUEST"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="CompleteResponse"/>
	<xsl:param name="Configs"/>
	<xsl:param name="ContactsJob"/>
	<xsl:param name="InProgress"/>
	<xsl:param name="IsEmpty"/>
	<xsl:param name="JobStatus"/>
	<xsl:param name="ReadExtract"/>
	<xsl:param name="ReadExtract_REQUEST"/>
	<xsl:param name="TerminationJob"/>
	<xsl:param name="WriteFile"/>
	<xsl:param name="WriteFile_REQUEST"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>

	<xsl:template match="/">
		<cjr:finalBatch>
			<cjr:bulkResponse>
				<xsl:choose>
					<xsl:when test="starts-with(/rqr:execute/rq:request-wrapper/rq:EmployeesBatch/rq:Extract/rq:FileName,'Employee_Extract')">
						<cjr:jobInfo>
							<cjr:id>
								<xsl:value-of select="$ContactsJob/uc:bulkResponse/uc:jobInfo/uc:id"/>
							</cjr:id>
							<cjr:operation>
								<xsl:value-of select="$ContactsJob/uc:bulkResponse/uc:jobInfo/uc:operation"/>
							</cjr:operation>
							<cjr:object>
								<xsl:value-of select="$ContactsJob/uc:bulkResponse/uc:jobInfo/uc:object"/>
							</cjr:object>
							<cjr:state>
								<xsl:value-of select="$ContactsJob/uc:bulkResponse/uc:jobInfo/uc:state"/>
							</cjr:state>
						</cjr:jobInfo>
						<cjr:batchInfo>
							<cjr:id>
								<xsl:value-of select="$ContactsJob/uc:bulkResponse/uc:batchInfo/uc:id"/>
							</cjr:id>
							<cjr:jobId>
								<xsl:value-of select="$ContactsJob/uc:bulkResponse/uc:batchInfo/uc:jobId"/>
							</cjr:jobId>
							<cjr:state>
								<xsl:value-of select="$ContactsJob/uc:bulkResponse/uc:batchInfo/uc:state"/>
							</cjr:state>
						</cjr:batchInfo>
					</xsl:when>
					<xsl:otherwise>
						<cjr:jobInfo>
							<cjr:id>
								<xsl:value-of select="$TerminationJob/ut:bulkResponse/ut:jobInfo/ut:id"/>
							</cjr:id>
							<cjr:operation>
								<xsl:value-of select="$TerminationJob/ut:bulkResponse/ut:jobInfo/ut:operation"/>
							</cjr:operation>
							<cjr:object>
								<xsl:value-of select="$TerminationJob/ut:bulkResponse/ut:jobInfo/ut:object"/>
							</cjr:object>
							<cjr:state>
								<xsl:value-of select="$TerminationJob/ut:bulkResponse/ut:jobInfo/ut:state"/>
							</cjr:state>
						</cjr:jobInfo>
						<cjr:batchInfo>
							<cjr:id>
								<xsl:value-of select="$TerminationJob/ut:bulkResponse/ut:batchInfo/ut:id"/>
							</cjr:id>
							<cjr:jobId>
								<xsl:value-of select="$TerminationJob/ut:bulkResponse/ut:batchInfo/ut:jobId"/>
							</cjr:jobId>
							<cjr:state>
								<xsl:value-of select="$TerminationJob/ut:bulkResponse/ut:batchInfo/ut:state"/>
							</cjr:state>
						</cjr:batchInfo>
					</xsl:otherwise>
				</xsl:choose>
			</cjr:bulkResponse>
		</cjr:finalBatch>
	</xsl:template>
</xsl:stylesheet>