<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ctar="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateContacts_REQUEST" xmlns:stgfr="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadExtractFile_REQUEST/types" xmlns:stgf="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadExtractFile" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:tns="urn:enterprise.soap.sforce.com" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:fns="urn:fault.enterprise.soap.sforce.com" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:nsmpr0="http://xmlns.oracle.com/cloud/adapter/salesforce/CompleteJob_REQUEST" xmlns:nsmpr1="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:nsmpr2="http://xmlns.oracle.com/cloud/adapter/salesforce/GetStatus_REQUEST" xmlns:nsmpr3="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types" xmlns:nsmpr4="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateTermination_REQUEST" xmlns:nsmpr5="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types" xmlns:nsmpr6="http://www.oracle.com/2014/03/ic/integration/metadata" version="2.0" exclude-result-prefixes=" oraext plnk xsd xp20 ns9 ora oracle-xsl-mapper nssrcmpr nssrcdfl xsi fn xsl ignore01 nsmpr0 nsmpr1 nsmpr2 nsmpr3 nsmpr4 nsmpr5 nsmpr6" ignore01:ignorexmlids="true">
        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_1418/resourcegroup_1419/ReadExtractFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadExtractFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtractFile"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_318/inbound_319/resourcegroup_367/UpdateContacts_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="upsert" namespace="http://xmlns.oracle.com/cloud/adapter/salesforce/UpdateContacts_REQUEST"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
        <xsl:param name="ReadExtractFile"/>
        <xsl:template match="/">
              <ctar:upsert>
                    <ctar:FF__Key_Contact__cs>
                          <xsl:for-each select="$ReadExtractFile/stgfr:ReadResponse/stgf:DATA_DS/stgf:G_1/stgf:G_2/stgf:FILE_FRAGMENT/stgf:Employee_Feed_V2/stgf:Person">
                                <xsl:variable name="assignment">
                                      <xsl:choose>
                                            <xsl:when test="count(stgf:Assignments/stgf:Assignment) = 1">
                                                  <xsl:copy-of select="stgf:Assignments/stgf:Assignment"/>
                                            </xsl:when>
                                            <xsl:when test="count(stgf:Assignments/stgf:Assignment) > 1">
                                                  <xsl:copy-of select="stgf:Assignments/stgf:Assignment[./stgf:Assignment_Details/stgf:Type = 'E' or ./stgf:Assignment_Details/stgf:Type = 'C'][1]"/>
                                            </xsl:when>
                                      </xsl:choose>
                                </xsl:variable>
                                <ctar:FF__Key_Contact__c>
                                      <ctar:externalIDFieldName>
                                            <xsl:value-of select="'Employee_ID__c'"/>
                                      </ctar:externalIDFieldName>
                                      <ctar:City__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:City)))">
                                                        <xsl:value-of select="stgf:Person_Details/stgf:City"/>
                                                  </xsl:when>
                                            </xsl:choose>
                                      </ctar:City__c>
                                      <ctar:Employee_ID__c>
                                            <xsl:value-of select="stgf:Person_Details/stgf:PersonNumber"/>
                                      </ctar:Employee_ID__c>
                                      <ctar:FF__Email__c>
                                            <xsl:value-of select="stgf:Person_Details/stgf:WorkEmail"/>
                                      </ctar:FF__Email__c>
                                      <ctar:FF__Company_Organization__c>
                                            <xsl:choose>
                                                  <xsl:when test="stgf:Person_Details/stgf:EmpType = 'EMP' and boolean(normalize-space(string($assignment/stgf:Assignment/stgf:Assignment_Details/stgf:Department)))">
                                                        <xsl:value-of select="$assignment/stgf:Assignment/stgf:Assignment_Details/stgf:Department"/>
                                                  </xsl:when>
                                                  <xsl:when test="stgf:Person_Details/stgf:EmpType = 'CWK'">Contractors</xsl:when>
                                            </xsl:choose>
                                      </ctar:FF__Company_Organization__c>
                                      <ctar:FF__First_Name__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:KnownAs)))">
                                                        <xsl:value-of select="stgf:Person_Details/stgf:KnownAs"/>
                                                  </xsl:when>
                                                  <xsl:otherwise>
                                                        <xsl:value-of select="stgf:Person_Details/stgf:FirstName"/>
                                                  </xsl:otherwise>
                                            </xsl:choose>
                                      </ctar:FF__First_Name__c>
                                      <ctar:FF__Last_Name__c>
                                            <xsl:value-of select="stgf:Person_Details/stgf:LastName"/>
                                      </ctar:FF__Last_Name__c>
                                      <ctar:FF__Mobile_Phone__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:MPhoneAreaCode))) and boolean(normalize-space(string(stgf:Person_Details/stgf:MPhone)))">
                                                        <xsl:value-of select="concat(stgf:Person_Details/stgf:MPhoneAreaCode,'-',stgf:Person_Details/stgf:MPhone)"/>
                                                  </xsl:when>
                                                  <xsl:otherwise>
                                                        <xsl:if test="boolean(normalize-space(string(stgf:Person_Details/stgf:MPhone)))">
                                                              <xsl:value-of select="stgf:Person_Details/stgf:MPhone"/>
                                                        </xsl:if>
                                                  </xsl:otherwise>
                                            </xsl:choose>
                                      </ctar:FF__Mobile_Phone__c>
                                      <ctar:FF__Phone__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:WPhoneAreaCode))) and boolean(normalize-space(string(stgf:Person_Details/stgf:WPhone)))">
                                                        <xsl:value-of select="concat(stgf:Person_Details/stgf:WPhoneAreaCode,'-',stgf:Person_Details/stgf:WPhone)"/>
                                                  </xsl:when>
                                                  <xsl:otherwise>
                                                        <xsl:if test="boolean(normalize-space(string(stgf:Person_Details/stgf:WPhone)))">
                                                              <xsl:value-of select="stgf:Person_Details/stgf:WPhone"/>
                                                        </xsl:if>
                                                  </xsl:otherwise>
                                            </xsl:choose>
                                      </ctar:FF__Phone__c>
                                      <ctar:FF__Title__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string($assignment/stgf:Assignment/stgf:Assignment_Details/stgf:Job_Name)))">
                                                        <xsl:value-of select="$assignment/stgf:Assignment/stgf:Assignment_Details/stgf:Job_Name"/>
                                                  </xsl:when>
                                            </xsl:choose>
                                      </ctar:FF__Title__c>
                                      <ctar:Home_Phone__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:HPhoneAreaCode))) and boolean(normalize-space(string(stgf:Person_Details/stgf:HPhone)))">
                                                        <xsl:value-of select="concat(stgf:Person_Details/stgf:HPhoneAreaCode,'-',stgf:Person_Details/stgf:HPhone)"/>
                                                  </xsl:when>
                                                  <xsl:otherwise>
                                                        <xsl:if test="boolean(normalize-space(string(stgf:Person_Details/stgf:HPhone)))">
                                                              <xsl:value-of select="stgf:Person_Details/stgf:HPhone"/>
                                                        </xsl:if>
                                                  </xsl:otherwise>
                                            </xsl:choose>
                                      </ctar:Home_Phone__c>
                                      <ctar:State__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:State)))">
                                                        <xsl:value-of select="stgf:Person_Details/stgf:State"/>
                                                  </xsl:when>
                                            </xsl:choose>
                                      </ctar:State__c>
                                      <ctar:Personal_Mobile_Phone__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:HMPhoneAreaCode))) and boolean(normalize-space(string(stgf:Person_Details/stgf:HMPhone)))">
                                                        <xsl:value-of select="concat(stgf:Person_Details/stgf:HMPhoneAreaCode,'-',stgf:Person_Details/stgf:HMPhone)"/>
                                                  </xsl:when>
                                                  <xsl:otherwise>
                                                        <xsl:if test="boolean(normalize-space(string(stgf:Person_Details/stgf:HMPhone)))">
                                                              <xsl:value-of select="stgf:Person_Details/stgf:HMPhone"/>
                                                        </xsl:if>
                                                  </xsl:otherwise>
                                            </xsl:choose>
                                      </ctar:Personal_Mobile_Phone__c>
                                      <ctar:Work_Location__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string($assignment/stgf:Assignment/stgf:Assignment_Details/stgf:Location)))">
                                                        <xsl:value-of select="$assignment/stgf:Assignment/stgf:Assignment_Details/stgf:Location"/>
                                                  </xsl:when>
                                            </xsl:choose>
                                      </ctar:Work_Location__c>
                                      <ctar:User_Status__c>
                                            <xsl:choose>
                                                  <xsl:when test="$assignment/stgf:Assignment/stgf:Assignment_Details/stgf:Status='SUSPENDED'">Terminated Assignment</xsl:when>
                                                  <xsl:otherwise>Active Assignment</xsl:otherwise>
                                            </xsl:choose>
                                      </ctar:User_Status__c>
                                      <ctar:Zip_Code__c>
                                            <xsl:choose>
                                                  <xsl:when test="boolean(normalize-space(string(stgf:Person_Details/stgf:PostalCode)))">
                                                        <xsl:value-of select="stgf:Person_Details/stgf:PostalCode"/>
                                                  </xsl:when>
                                            </xsl:choose>
                                      </ctar:Zip_Code__c>
                                </ctar:FF__Key_Contact__c>
                          </xsl:for-each>
                    </ctar:FF__Key_Contact__cs>
              </ctar:upsert>
        </xsl:template>
  </xsl:stylesheet>