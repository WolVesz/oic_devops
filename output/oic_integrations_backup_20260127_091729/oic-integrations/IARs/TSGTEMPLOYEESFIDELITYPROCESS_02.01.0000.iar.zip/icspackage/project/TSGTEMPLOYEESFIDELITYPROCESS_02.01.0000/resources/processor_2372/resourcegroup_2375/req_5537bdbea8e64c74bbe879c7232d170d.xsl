<xsl:stylesheet xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:audr="http://xmlns.oracle.com/cloud/adapter/REST/PublishError4Employee_REQUEST/types" xmlns:aud="http://xmlns.oracle.com/cloud/adapter/REST/PublishError4Employee/types" xmlns:tgrr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types" xmlns:tgr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:med="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:ic="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" xmlns:fault="http://www.oracle.com/2014/03/ics/fault" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:nssrcdfl="http://xmlns.oracle.com/procmon" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:nsmpr0="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" version="2.0" exclude-result-prefixes=" ns3 oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2550/inbound_2551/resourcegroup_2552/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFileResponse" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_2355/resourcegroup_2356/ICSFault.xsd"/>
                          <oracle-xsl-mapper:rootElement name="fault" namespace="http://www.oracle.com/2014/03/ics/fault"/>
                          <oracle-xsl-mapper:param name="Scope_ExtractFaultObject"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_222/resourcegroup_223/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2360/inbound_2361/resourcegroup_2362/PublishError4Employee_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/PublishError4Employee_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="InProgress"/>
	<xsl:param name="IsEmpty"/>
	<xsl:param name="ReadExtract"/>
	<xsl:param name="ReadExtract_REQUEST"/>
	<xsl:param name="Scope_ExtractFaultObject"/>
	<xsl:param name="WriteFile"/>
	<xsl:param name="WriteFile_REQUEST"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>

	<xsl:template match="/">
		<audr:execute>
			<audr:request-wrapper>
				<aud:Auditing>
					<aud:AuditingType>
						<xsl:value-of select="'Error'"/>
					</aud:AuditingType>
					<aud:FlowInstanceID>
						<xsl:value-of select="ic:getFlowId()"/>
					</aud:FlowInstanceID>
					<aud:TrackingID>
						<xsl:value-of select="concat($self/med:metadata/med:integration/med:name, '-', xp20:format-dateTime (fn:current-dateTime(), '[Y0001]-[M01]-[D01]'))"/>
					</aud:TrackingID>
					<aud:ReferenceID>
						<xsl:value-of select="concat ($self/med:metadata/med:integration/med:name, '-', xp20:format-dateTime (fn:current-dateTime(), '[Y0001]-[M01]-[D01]'))"/>
					</aud:ReferenceID>
					<aud:InterfaceName>
						<xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
					</aud:InterfaceName>
					<aud:Title>
						<xsl:value-of select="concat($self/med:metadata/med:integration/med:name, &quot; - Employee record - Error - &quot;, ic:getFlowId())"/>
					</aud:Title>
					<aud:Details>
						<xsl:value-of select="concat (&quot;ErrorCode:&quot;, $Scope_ExtractFaultObject/fault:fault/fault:errorCode, &quot;; reason:&quot;, $Scope_ExtractFaultObject/fault:fault/fault:reason, &quot;; details:&quot;, $Scope_ExtractFaultObject/fault:fault/fault:details )"/>
					</aud:Details>
					<aud:Payload>
						<xsl:value-of select="oraext:get-content-as-string(/tgrr:execute/tgr:request-wrapper/tgr:EmployeesBatch)"/>
					</aud:Payload>
					<aud:AuditingID>
						<xsl:value-of select="oraext:generate-guid ()"/>
					</aud:AuditingID>
				</aud:Auditing>
			</audr:request-wrapper>
		</audr:execute>
	</xsl:template>
</xsl:stylesheet>