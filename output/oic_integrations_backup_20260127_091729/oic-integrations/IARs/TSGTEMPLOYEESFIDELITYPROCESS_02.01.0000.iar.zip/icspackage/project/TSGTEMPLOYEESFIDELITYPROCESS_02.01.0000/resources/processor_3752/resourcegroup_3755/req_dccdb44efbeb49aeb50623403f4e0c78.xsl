<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:tgtr="http://xmlns.oracle.com/cloud/adapter/ftp/WriteNonQualTFile_REQUEST/types" xmlns:tgt="http://TargetNamespace.com/fileReference/WriteNonQualTFile" xmlns:sour="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadTerminationFile_REQUEST/types" xmlns:sou="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadTerminationFile" xmlns:header="http://xml.oracle.com/types" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:reportr="http://xmlns.oracle.com/cloud/adapter/stagefile/Read401kTEmployeeFile_REQUEST/types" xmlns:report="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/Read401kTEmployeeFile" xmlns:levr="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadNonQualEmployeeTFile_REQUEST/types" xmlns:lev="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadNonQualEmployeeTFile" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" exclude-result-prefixes=" oraext plnk xsd xp20 ns9 ora oracle-xsl-mapper nssrcmpr nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2550/inbound_2551/resourcegroup_2552/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2891/inbound_2892/resourcegroup_2893/Write401kFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/Write401kFile"/>
                          <oracle-xsl-mapper:param name="Employees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3629/inbound_3630/resourcegroup_3631/GetNonQualTEmployees_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="runReportResponse" namespace="http://xmlns.oracle.com/oxp/service/PublicReportService"/>
                          <oracle-xsl-mapper:param name="GetNonQualTEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3629/inbound_3630/resourcegroup_3631/GetNonQualTEmployees_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/GetNonQualTEmployees/1696710224701/OutboundSOAPRequestDocument"/>
                          <oracle-xsl-mapper:param name="GetNonQualTEmployees_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3544/inbound_3545/resourcegroup_3546/WriteNonQualFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/WriteNonQualFile"/>
                          <oracle-xsl-mapper:param name="NonQualEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFileResponse" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_3701/resourcegroup_3702/ReadNonQualEmployeeTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadNonQualEmployeeTFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadNonQualEmployeeTFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_2265/resourcegroup_2266/ReadTerminationFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadTerminationFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadTerminationFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3210/inbound_3211/resourcegroup_3212/Write401kTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/Write401kTFile"/>
                          <oracle-xsl-mapper:param name="TEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3742/inbound_3743/resourcegroup_3744/WriteNonQualTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/WriteNonQualTFile"/>
                          <oracle-xsl-mapper:param name="TNonQualEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_3650/resourcegroup_3651/WriteNonQualEmployeeTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteNonQualEmployeeTFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteNonQualEmployeeTFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_3650/resourcegroup_3651/WriteNonQualEmployeeTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteNonQualEmployeeTFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteNonQualEmployeeTFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_222/resourcegroup_223/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3742/inbound_3743/resourcegroup_3744/WriteNonQualTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/WriteNonQualTFile_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="Employees"/>
	<xsl:param name="GetNonQualTEmployees"/>
	<xsl:param name="GetNonQualTEmployees_REQUEST"/>
	<xsl:param name="InProgress"/>
	<xsl:param name="IsEmpty"/>
	<xsl:param name="NonQualEmployees"/>
	<xsl:param name="ReadExtract"/>
	<xsl:param name="ReadExtract_REQUEST"/>
	<xsl:param name="ReadNonQualEmployeeTFile"/>
	<xsl:param name="ReadTerminationFile"/>
	<xsl:param name="TEmployees"/>
	<xsl:param name="TNonQualEmployees"/>
	<xsl:param name="WriteFile"/>
	<xsl:param name="WriteFile_REQUEST"/>
	<xsl:param name="WriteNonQualEmployeeTFile"/>
	<xsl:param name="WriteNonQualEmployeeTFile_REQUEST"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>

	<xsl:template match="/">
		<tgtr:WriteFile>
			<tgtr:OutboundFTPHeaderType>
				  <header:fileName>
						<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='NonQualStagingFileName']/cfg:Value"/>
				  </header:fileName>
				  <header:directory>
						<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='401StagingFolder']/cfg:Value"/>
				  </header:directory>
			</tgtr:OutboundFTPHeaderType>
			<tgt:Lines>
				<xsl:for-each select="$ReadTerminationFile/sour:ReadResponse/sou:DATA_DS/sou:G_1/sou:G_2/sou:FILE_FRAGMENT/sou:Employee_Feed_V2/sou:Assigment[sou:Assignment/sou:JobName!='Member of the Board' and (sou:Assignment/sou:AssignmentCategory='Full-time regular' or sou:Assignment/sou:AssignmentCategory='Part-time regular' or sou:Assignment/sou:AssignmentCategory='Three Quarter Time')]">
					<xsl:variable name="personnumber" select="sou:Person/sou:Person/sou:Person/sou:PersonNumber"/>

					<xsl:if test="count($ReadNonQualEmployeeTFile/levr:ReadResponse/lev:DATA_DS/lev:G_1[(number(lev:NEW_LEVEL) >= 20) and lev:PERSON_NUMBER=string($personnumber)]) > 0">

					<xsl:variable name="staratdatefield">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Assignment/sou:StartDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Assignment/sou:StartDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="dob">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Person/sou:Person/sou:Person/sou:DOB))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person/sou:Person/sou:Person/sou:DOB, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="hiredate">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Person/sou:Person/sou:Person/sou:OriginalHireDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person/sou:Person/sou:Person/sou:OriginalHireDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:when test="boolean(string(sou:Person/sou:Person/sou:Person/sou:EnterpriseHireDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person/sou:Person/sou:Person/sou:EnterpriseHireDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="terminationdate">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Assignment/sou:TerminationDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Assignment/sou:TerminationDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>
					
					<tgt:Line>
						<tgt:C1>
							<xsl:value-of select="concat('40389       ',normalize-space(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID))),'      02D','    ',string($hiredate),'                ',string($dob),string($terminationdate),'5   ')"/>
						</tgt:C1>
					</tgt:Line>
					<tgt:Line>
						<tgt:C1>
							<xsl:value-of select="concat('40389       ',normalize-space(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID))),'      11','E     ',string($terminationdate),'                                   ')"/>
						</tgt:C1>
					</tgt:Line>

					<xsl:choose>
						<xsl:when test="sou:Assignment/sou:ActionCode='RETIREMENT'">
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID))),'      61        ',string($hiredate),string($terminationdate),'                    ')"/>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person/sou:Person/sou:Person/sou:PrimaryNationalID))),'      61        ',string($hiredate),string($terminationdate),'                    ')"/>
								</tgt:C1>
							</tgt:Line>
						</xsl:when>
					</xsl:choose>
								
					</xsl:if>
				</xsl:for-each>
			</tgt:Lines>
		</tgtr:WriteFile>
	</xsl:template>
</xsl:stylesheet>