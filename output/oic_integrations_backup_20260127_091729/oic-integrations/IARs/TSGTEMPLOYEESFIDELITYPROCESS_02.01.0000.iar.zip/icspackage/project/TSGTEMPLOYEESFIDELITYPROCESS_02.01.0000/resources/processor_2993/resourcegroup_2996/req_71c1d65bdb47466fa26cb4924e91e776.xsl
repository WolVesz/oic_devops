<xsl:stylesheet version="2.0" xmlns:tgtr="http://xmlns.oracle.com/cloud/adapter/ftp/Write401kFile_REQUEST/types" xmlns:tgt="http://TargetNamespace.com/fileReference/Write401kFile" xmlns:sour="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadExtractFile_REQUEST/types" xmlns:sou="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadExtractFile" xmlns:header="http://xml.oracle.com/types" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:reportr="http://xmlns.oracle.com/cloud/adapter/stagefile/Read401kEmployeeFile_REQUEST/types" xmlns:report="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/Read401kEmployeeFile" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" exclude-result-prefixes=" oraext plnk xsd xp20 ns9 ora oracle-xsl-mapper nssrcmpr nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2550/inbound_2551/resourcegroup_2552/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFileResponse" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_2203/resourcegroup_2204/ReadExtractFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadExtractFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtractFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_222/resourcegroup_223/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2891/inbound_2892/resourcegroup_2893/Write401kFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/Write401kFile_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="InProgress"/>
	<xsl:param name="IsEmpty"/>
	<xsl:param name="ReadExtract"/>
	<xsl:param name="ReadExtractFile"/>
	<xsl:param name="ReadExtract_REQUEST"/>
	<xsl:param name="WriteFile"/>
	<xsl:param name="WriteFile_REQUEST"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
		
	<xsl:template match="/">
		<tgtr:WriteFile>
			<tgtr:OutboundFTPHeaderType>
				  <header:fileName>
						<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='401StagingFileName']/cfg:Value"/>
				  </header:fileName>
				  <header:directory>
						<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='401StagingFolder']/cfg:Value"/>
				  </header:directory>
			</tgtr:OutboundFTPHeaderType>
			<tgt:Lines>
			
				<xsl:variable name="parameter">
					<xsl:choose>
						<xsl:when test="count($ReadExtractFile/sour:ReadResponse/sou:DATA_DS/sou:G_1/sou:G_2/sou:FILE_FRAGMENT/sou:parameters) > 0">
							<xsl:value-of select="$ReadExtractFile/sour:ReadResponse/sou:DATA_DS/sou:G_1/sou:G_2/sou:FILE_FRAGMENT/sou:parameters/sou:effective_date"/>
						</xsl:when>
						<xsl:when test="count($ReadExtractFile/sour:ReadResponse/sou:DATA_DS/sou:G_1/sou:G_2/sou:FILE_FRAGMENT/sou:Employee_Feed_V2/sou:parameters) > 0">
							<xsl:value-of select="$ReadExtractFile/sour:ReadResponse/sou:DATA_DS/sou:G_1/sou:G_2/sou:FILE_FRAGMENT/sou:Employee_Feed_V2/sou:parameters/sou:effective_date"/>
						</xsl:when>
					</xsl:choose>
				</xsl:variable>
			
				<xsl:for-each select="$ReadExtractFile/sour:ReadResponse/sou:DATA_DS/sou:G_1/sou:G_2/sou:FILE_FRAGMENT/sou:Employee_Feed_V2/sou:Person[sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:Job_Name!='Member of the Board' and (sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:AssignmentCategory='Full-time regular' or sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:AssignmentCategory='Part-time regular' or sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:AssignmentCategory='Three Quarter Time')]">
					<xsl:variable name="personnumber" select="sou:Person_Details/sou:PersonNumber"/>
					
					<xsl:variable name="maritalstatus">
						<xsl:choose>
							<xsl:when test="sou:Person_Details/sou:MaritalStatus='M'">M</xsl:when>
							<xsl:when test="sou:Person_Details/sou:MaritalStatus='S'">S</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="' '"/>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="gender">
						<xsl:choose>
							<xsl:when test="sou:Person_Details/sou:Gender='M'">M</xsl:when>
							<xsl:when test="sou:Person_Details/sou:Gender='F'">F</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="' '"/>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>
					

					<xsl:variable name="rehire">
						<xsl:choose>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:ActionCode='REHIRE'">5</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="' '"/>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="status">
						<xsl:choose>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:ActionCode='REHIRE'">H</xsl:when>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:ActionCode='HIRE'">N</xsl:when>
							<xsl:otherwise>A</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="location">
						<xsl:choose>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Tri-State Generation and Transmission Association, Inc.' and sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:UnionMember='Y'">TSB</xsl:when>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Tri-State Generation and Transmission Association, Inc.'">TSNB</xsl:when>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Elk Ridge Mining and Reclamation' and sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:UnionMember='Y'">ERMRB</xsl:when>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Elk Ridge Mining and Reclamation'">ERMRNB</xsl:when>									
							<xsl:when test="starts-with(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity,'Colowyo')">COLOWYO</xsl:when>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="unioncode">
						<xsl:choose>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Tri-State Generation and Transmission Association, Inc.' and sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:UnionMember='Y' and sou:Person_Details/sou:HireDate &lt;= '2021-07-01T00:00:00.000Z'">12MONTH</xsl:when>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Tri-State Generation and Transmission Association, Inc.' ">1MONTH</xsl:when>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Elk Ridge Mining and Reclamation' and sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:UnionMember='Y'">1MONTH</xsl:when>
							<xsl:when test="sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity='Elk Ridge Mining and Reclamation'">12MONTH</xsl:when>									
							<xsl:when test="starts-with(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity,'Colowyo') and sou:Person_Details/sou:HireDate &lt;= '2021-07-01T00:00:00.000Z'">12MONTH</xsl:when>
							<xsl:when test="starts-with(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:LegalEntity,'Colowyo')">1MONTH</xsl:when>
						</xsl:choose>
					</xsl:variable>
					
					<xsl:variable name="category">
						<xsl:choose>
							<xsl:when test="starts-with(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:AssignmentCategory,'Full-time')">F</xsl:when>
							<xsl:when test="starts-with(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:AssignmentCategory,'Part-time')">P</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="' '"/>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="salary">
						<xsl:choose>
							<xsl:when test="number(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:Salary) > 120000">Y</xsl:when>
							<xsl:otherwise>N</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>
					
					<xsl:variable name="staratdate">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:StartDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:StartDate, '[Y0001]-[M01]-[D01]')"/>
							</xsl:when>
							<!--
							<xsl:when test="boolean(string(sou:Person_Details/sou:HireDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person_Details/sou:HireDate, '[Y0001]-[M01]-[D01]')"/>
							</xsl:when>
							-->
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="staratdatefield">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:StartDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Assignments/sou:Assignment/sou:Assignment_Details/sou:StartDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<!--
							<xsl:when test="boolean(string(sou:Person_Details/sou:HireDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person_Details/sou:HireDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							-->
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="dob">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Person_Details/sou:DOB))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person_Details/sou:DOB, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="hiredate">
						<xsl:choose>
							<xsl:when test="boolean(string(sou:Person_Details/sou:OriginalHireDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person_Details/sou:OriginalHireDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:when test="boolean(string(sou:Person_Details/sou:EnterpriseHireDate))">
								<xsl:value-of select="xp20:format-dateTime(sou:Person_Details/sou:EnterpriseHireDate, '[M01][D01][Y0001]')"/>
							</xsl:when>
							<xsl:otherwise>00000000</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="firstname">
						<xsl:choose>
							<xsl:when test="string-length(normalize-space(sou:Person_Details/sou:FirstName)) > 15">
								<xsl:value-of select="substring(normalize-space(sou:Person_Details/sou:FirstName),1,15)"/>
							</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="normalize-space(sou:Person_Details/sou:FirstName)"/>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>

					<xsl:variable name="lastname">
						<xsl:choose>
							<xsl:when test="string-length(normalize-space(sou:Person_Details/sou:LastName)) > 20">
								<xsl:value-of select="substring(normalize-space(sou:Person_Details/sou:LastName),1,20)"/>
							</xsl:when>
							<xsl:otherwise>
								<xsl:value-of select="normalize-space(sou:Person_Details/sou:LastName)"/>
							</xsl:otherwise>
						</xsl:choose>
					</xsl:variable>
					
					<xsl:choose>
						<!-- new hire and rehire -->
						<xsl:when test="(string($status)='H' or string($status)='N') and string($staratdate)=string($parameter)">
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      01',fn:upper-case(string($lastname)),substring('                    ',1,(20 - string-length(string($lastname)))),fn:upper-case(string($firstname)),substring('               ',1,(15 - string-length(string($firstname)))),'         ',fn:upper-case(string($maritalstatus)),fn:upper-case(string($gender)),'   ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      02D','    ',string($hiredate),'                ',string($dob),'00000000',string($rehire),'   ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      02E',normalize-space(sou:Person_Details/sou:PersonNumber),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PersonNumber))),'                                     ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      03P01',normalize-space(fn:upper-case(sou:Person_Details/sou:Address1)),substring('                                ',1,(32 - string-length(sou:Person_Details/sou:Address1))),'              ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      03P02',normalize-space(fn:upper-case(sou:Person_Details/sou:Address2)),substring('                                ',1,(32 - string-length(sou:Person_Details/sou:Address2))),'              ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      03P03',normalize-space(fn:upper-case(sou:Person_Details/sou:Address3)),substring('                                ',1,(32 - string-length(sou:Person_Details/sou:Address3))),'              ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      04P',normalize-space(fn:upper-case(sou:Person_Details/sou:City)),substring('                    ',1,(20 - string-length(sou:Person_Details/sou:City))),normalize-space(fn:upper-case(sou:Person_Details/sou:State)),substring('  ',1,(2 - string-length(sou:Person_Details/sou:State))),'        ',normalize-space(fn:upper-case(sou:Person_Details/sou:PostalCode)),substring('     ',1,(5 - string-length(sou:Person_Details/sou:PostalCode))),'             ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      11',string($status),'     ',string($staratdatefield),'                                   ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      60',string($category),'                ',normalize-space($location),substring('        ',1,(8 - string-length(normalize-space($location)))),normalize-space($unioncode),substring('        ',1,(8 - string-length(normalize-space($unioncode)))),'         ',string($salary),'      ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<xsl:choose>
									<xsl:when test="string($status)='H'">
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      61        ',xp20:format-dateTime(sou:Person_Details/sou:HireDate, '[M01][D01][Y0001]'),'0000000000000                    ')"/>
										</tgt:C1>
									</xsl:when>
									<xsl:when test="string($status)='N'">
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      61        ',string($hiredate),'0000000000000                    ')"/>
										</tgt:C1>
									</xsl:when>
								</xsl:choose>
								
							</tgt:Line>
							<xsl:choose>
								<xsl:when test="string-length(sou:Person_Details/sou:WorkEmail) &lt;=35 ">
									<tgt:Line>
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      EAAER  1',normalize-space(fn:upper-case(sou:Person_Details/sou:WorkEmail)),substring('                                   ',1,(35 - string-length(sou:Person_Details/sou:WorkEmail))),'        ')"/>
										</tgt:C1>
									</tgt:Line>
								</xsl:when>
								<xsl:when test="string-length(sou:Person_Details/sou:WorkEmail) >35 and string-length(sou:Person_Details/sou:WorkEmail) &lt;= 70">
									<tgt:Line>
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      EAAER  1',substring(normalize-space(fn:upper-case(sou:Person_Details/sou:WorkEmail)),1,35),'        ')"/>
										</tgt:C1>
									</tgt:Line>
									<tgt:Line>
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      EAAER  2',normalize-space(fn:upper-case(substring(sou:Person_Details/sou:WorkEmail,36,35))),substring('                                   ',1,(35 - string-length(sou:Person_Details/sou:WorkEmail))),'        ')"/>
										</tgt:C1>
									</tgt:Line>
								</xsl:when>
								<xsl:when test="string-length(sou:Person_Details/sou:WorkEmail) >75">
									<tgt:Line>
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      EAAER  1',substring(normalize-space(fn:upper-case(sou:Person_Details/sou:WorkEmail)),1,35),'        ')"/>
										</tgt:C1>
									</tgt:Line>
									<tgt:Line>
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      EAAER  2',normalize-space(fn:upper-case(substring(sou:Person_Details/sou:WorkEmail,36,35))),substring('                                   ',1,(35 - string-length(sou:Person_Details/sou:WorkEmail))),'        ')"/>
										</tgt:C1>
									</tgt:Line>
									<tgt:Line>
										<tgt:C1>
											<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      EAAER  3',normalize-space(fn:upper-case(substring(sou:Person_Details/sou:WorkEmail,36,35))),substring('                                   ',1,(35 - string-length(sou:Person_Details/sou:WorkEmail))),'        ')"/>
										</tgt:C1>
									</tgt:Line>
								</xsl:when>
							</xsl:choose>
						</xsl:when>
						<xsl:when test="sou:Person_Details/sou:Address1 != sou:Person_Details/sou:Address1_OLD or sou:Person_Details/sou:Address2 != sou:Person_Details/sou:Address2_OLD or sou:Person_Details/sou:Address3 != sou:Person_Details/sou:Address3_OLD or sou:Person_Details/sou:City != sou:Person_Details/sou:City_OLD or sou:Person_Details/sou:State != sou:Person_Details/sou:State_OLD or sou:Person_Details/sou:PostalCode != sou:Person_Details/sou:PostalCode_OLD">
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      03P01',normalize-space(fn:upper-case(sou:Person_Details/sou:Address1)),substring('                                ',1,(32 - string-length(sou:Person_Details/sou:Address1))),'              ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      03P02',normalize-space(fn:upper-case(sou:Person_Details/sou:Address2)),substring('                                ',1,(32 - string-length(sou:Person_Details/sou:Address2))),'              ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      03P03',normalize-space(fn:upper-case(sou:Person_Details/sou:Address3)),substring('                                ',1,(32 - string-length(sou:Person_Details/sou:Address3))),'              ')"/>
								</tgt:C1>
							</tgt:Line>
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      04P',fn:upper-case(normalize-space(sou:Person_Details/sou:City)),substring('                    ',1,(20 - string-length(sou:Person_Details/sou:City))),fn:upper-case(normalize-space(sou:Person_Details/sou:State)),substring('  ',1,(2 - string-length(sou:Person_Details/sou:State))),'        ',normalize-space(sou:Person_Details/sou:PostalCode),substring('     ',1,(5 - string-length(sou:Person_Details/sou:PostalCode))),'             ')"/>
								</tgt:C1>
							</tgt:Line>
						</xsl:when>
						<xsl:when test="sou:Person_Details/sou:FirstName != sou:Person_Details/sou:FirstName_OLD or sou:Person_Details/sou:LastName != sou:Person_Details/sou:LastName_OLD or sou:Person_Details/sou:MiddleName != sou:Person_Details/sou:MiddleName_OLD">
							<tgt:Line>
								<tgt:C1>
									<xsl:value-of select="concat('40389       ',normalize-space(sou:Person_Details/sou:PrimaryNationalID),substring('           ',1,(11 - string-length(sou:Person_Details/sou:PrimaryNationalID))),'      01',fn:upper-case(string($lastname)),substring('                    ',1,(20 - string-length(string($lastname)))),fn:upper-case(string($firstname)),substring('               ',1,(15 - string-length(string($firstname)))),'         ',fn:upper-case(string($maritalstatus)),fn:upper-case(string($gender)),'   ')"/>
								</tgt:C1>
							</tgt:Line>
						</xsl:when>
					</xsl:choose>
								
				</xsl:for-each>
			</tgt:Lines>
		</tgtr:WriteFile>
	</xsl:template>
</xsl:stylesheet>