<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:rptw="http://xmlns.oracle.com/types/GetNonQualTEmployees/1696710224701/OutboundSOAPRequestDocument" xmlns:report="http://xmlns.oracle.com/oxp/service/PublicReportService" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:etfr="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadTerminationFile_REQUEST/types" xmlns:etf="http://xmlns.oracle.com/cloud/adapter/nxsd/surrogate/ReadTerminationFile" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:srcr="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST/types" xmlns:src="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger/types" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" xml:id="id_1" exclude-result-prefixes=" oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ns1 ignore01" ignore01:ignorexmlids="true" xmlns:xml="http://www.w3.org/XML/1998/namespace">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2550/inbound_2551/resourcegroup_2552/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2891/inbound_2892/resourcegroup_2893/Write401kFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/Write401kFile"/>
                          <oracle-xsl-mapper:param name="Employees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3544/inbound_3545/resourcegroup_3546/WriteNonQualFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/WriteNonQualFile"/>
                          <oracle-xsl-mapper:param name="NonQualEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFileResponse" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_129/inbound_130/resourcegroup_131/ReadExtract_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="SyncReadFile" namespace="http://xmlns.oracle.com/cloud/adapter/ftp/ReadExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadExtract_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_2265/resourcegroup_2266/ReadTerminationFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadTerminationFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadTerminationFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3210/inbound_3211/resourcegroup_3212/Write401kTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/Write401kTFile"/>
                          <oracle-xsl-mapper:param name="TEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3742/inbound_3743/resourcegroup_3744/WriteNonQualTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/WriteNonQualTFile"/>
                          <oracle-xsl-mapper:param name="TNonQualEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_145/resourcegroup_146/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_222/resourcegroup_223/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3629/inbound_3630/resourcegroup_3631/GetNonQualTEmployees_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/GetNonQualTEmployees/1696710224701/OutboundSOAPRequestDocument"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="Employees"/>
	<xsl:param name="InProgress"/>
	<xsl:param name="IsEmpty"/>
	<xsl:param name="NonQualEmployees"/>
	<xsl:param name="ReadExtract"/>
	<xsl:param name="ReadExtract_REQUEST"/>
	<xsl:param name="ReadTerminationFile"/>
	<xsl:param name="TEmployees"/>
	<xsl:param name="TNonQualEmployees"/>
	<xsl:param name="WriteFile"/>
	<xsl:param name="WriteFile_REQUEST"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:variable name="list">
		<xsl:for-each select="$ReadTerminationFile/etfr:ReadResponse/etf:DATA_DS/etf:G_1/etf:G_2/etf:FILE_FRAGMENT/etf:Employee_Feed_V2/etf:Assigment">
			<xsl:choose>
				<xsl:when test="position() = last()">
					<xsl:value-of select="etf:Person/etf:Person/etf:Person/etf:PersonNumber"/>
				</xsl:when>
				<xsl:otherwise>
					<xsl:value-of select="concat(etf:Person/etf:Person/etf:Person/etf:PersonNumber,',')"/>
				</xsl:otherwise>
			</xsl:choose>
		</xsl:for-each>
	</xsl:variable>
	
	<xsl:template match="/">
		<rptw:OutboundSOAPRequestDocument>
			<rptw:Body>
				<report:runReport>
					<report:reportRequest>
						<report:parameterNameValues>
							<report:item>
								<report:name>p_in_employees</report:name>
								<report:values>
									<report:item>
										<xsl:value-of select="string($list)"/>
									</report:item>
								</report:values>
							</report:item>
						</report:parameterNameValues>
						<report:reportAbsolutePath>
							<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='NonQualEmployeeReport']/cfg:Value"/>
						</report:reportAbsolutePath>
					    <report:sizeOfDataChunkDownload>-1</report:sizeOfDataChunkDownload>
					</report:reportRequest>
				</report:runReport>
			</rptw:Body>
		</rptw:OutboundSOAPRequestDocument>
	</xsl:template>
</xsl:stylesheet>