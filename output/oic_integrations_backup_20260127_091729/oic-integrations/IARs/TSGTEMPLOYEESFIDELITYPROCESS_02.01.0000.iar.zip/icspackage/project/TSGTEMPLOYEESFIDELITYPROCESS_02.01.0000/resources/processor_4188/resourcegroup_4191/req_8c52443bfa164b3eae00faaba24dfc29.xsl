<xsl:stylesheet version="2.0" xmlns:audr="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing_REQUEST/types" xmlns:aud="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:tgrr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types" xmlns:tgr="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger/types" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:fault="http://www.oracle.com/2014/03/ics/fault" xmlns:med="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:ic="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" exclude-result-prefixes=" oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper xsi fn xsl ignore01" ignore01:ignorexmlids="true">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_13/outbound_14/resourcegroup_15/EmployeeTrigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/EmployeeTrigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2550/inbound_2551/resourcegroup_2552/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_2891/inbound_2892/resourcegroup_2893/Write401kFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/Write401kFile"/>
                          <oracle-xsl-mapper:param name="Employees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_497/resourcegroup_498/ICSFault.xsd"/>
                          <oracle-xsl-mapper:rootElement name="fault" namespace="http://www.oracle.com/2014/03/ics/fault"/>
                          <oracle-xsl-mapper:param name="GlobalFaultObject"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3544/inbound_3545/resourcegroup_3546/WriteNonQualFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/WriteNonQualFile"/>
                          <oracle-xsl-mapper:param name="NonQualEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3210/inbound_3211/resourcegroup_3212/Write401kTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/Write401kTFile"/>
                          <oracle-xsl-mapper:param name="TEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_3742/inbound_3743/resourcegroup_3744/WriteNonQualTFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Lines" namespace="http://TargetNamespace.com/fileReference/WriteNonQualTFile"/>
                          <oracle-xsl-mapper:param name="TNonQualEmployees"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_222/resourcegroup_223/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_4161/inbound_4162/resourcegroup_4163/PublishAuditing_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="Employees"/>
	<xsl:param name="GlobalFaultObject"/>
	<xsl:param name="InProgress"/>
	<xsl:param name="IsEmpty"/>
	<xsl:param name="NonQualEmployees"/>
	<xsl:param name="TEmployees"/>
	<xsl:param name="TNonQualEmployees"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
		
	<xsl:template match="/">
		<audr:execute>
			<aud:request-wrapper>
				<aud:Auditing>
				
					<aud:AuditingType>
						<xsl:value-of select="'Error'"/>
					</aud:AuditingType>
					<aud:FlowInstanceID>
						<xsl:value-of select="ic:getFlowId()"/>
					</aud:FlowInstanceID>
					<aud:TrackingID>
						<xsl:value-of select="concat($self/med:metadata/med:integration/med:name, '-', xp20:format-dateTime (fn:current-dateTime(), '[Y0001]-[M01]-[D01]'))"/>
					</aud:TrackingID>
					<aud:ReferenceID>
						<xsl:value-of select="concat ($self/med:metadata/med:integration/med:name, '-', xp20:format-dateTime (fn:current-dateTime(), '[Y0001]-[M01]-[D01]'))"/>
					</aud:ReferenceID>
					<aud:InterfaceName>
						<xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
					</aud:InterfaceName>
					<aud:Title>
						<xsl:value-of select="concat($self/med:metadata/med:integration/med:name, ' - Error - ', ic:getFlowId())"/>
					</aud:Title>
					<aud:Details>
						<xsl:value-of select="concat ('ErrorCode:', $GlobalFaultObject/fault:fault/fault:errorCode, '; reason:', $GlobalFaultObject/fault:fault/fault:reason, '; details:', $GlobalFaultObject/fault:fault/fault:details )"/> 
					</aud:Details>
					<aud:Payload>
						<xsl:value-of select="oraext:get-content-as-string(/tgrr:execute/tgr:request-wrapper/tgr:EmployeesBatch)"/>
					</aud:Payload>
					<aud:AuditingID>
						<xsl:value-of select="oraext:generate-guid ()"/>
					</aud:AuditingID>

				</aud:Auditing>
			</aud:request-wrapper>
		</audr:execute>

	</xsl:template>
	
</xsl:stylesheet>