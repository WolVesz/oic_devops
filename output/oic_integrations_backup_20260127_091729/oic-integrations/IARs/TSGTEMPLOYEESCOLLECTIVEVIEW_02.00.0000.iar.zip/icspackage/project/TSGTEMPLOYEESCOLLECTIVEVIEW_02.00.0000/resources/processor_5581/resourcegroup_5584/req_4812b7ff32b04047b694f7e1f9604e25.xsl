<xsl:stylesheet version="2.0" xmlns:audr="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing_REQUEST/types" xmlns:aud="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing/types" xmlns:reqr="http://xmlns.oracle.com/cloud/adapter/REST/Trigger_REQUEST/types" xmlns:req="http://xmlns.oracle.com/cloud/adapter/REST/Trigger/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" xmlns:fault="http://www.oracle.com/2014/03/ics/fault" xmlns:med="http://www.oracle.com/2014/03/ic/integration/metadata" xmlns:ic="http://www.oracle.com/XSL/Transform/java/com.bea.wli.sb.resources.icsxpathfunctions.ICSInstanceTrackingFunctions" exclude-result-prefixes=" oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ignore01" ignore01:ignorexmlids="true">
				
	<oracle-xsl-mapper:schema xml:id="id_2">				
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_5457/outbound_5458/resourcegroup_5459/Trigger_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/Trigger_REQUEST/types"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_5376/resourcegroup_5379/generated.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="HcmDataExtractResponse" namespace="http://xmlns.oracle.com/cloud/adapter/hcm/EmployeesExtract_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="Extact"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_1719/resourcegroup_1720/ICSFault.xsd"/>
                          <oracle-xsl-mapper:rootElement name="fault" namespace="http://www.oracle.com/2014/03/ics/fault"/>
                          <oracle-xsl-mapper:param name="GlobalFaultObject"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_5255/inbound_5256/resourcegroup_5257/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_4682/resourcegroup_4683/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_5569/inbound_5570/resourcegroup_5571/PublishAuditing_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="execute" namespace="http://xmlns.oracle.com/cloud/adapter/REST/PublishAuditing_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
        <xsl:param name="DocumentID"/>
        <xsl:param name="Extact"/>
        <xsl:param name="GlobalFaultObject"/>
        <xsl:param name="configs"/>
        <xsl:param name="self"/>
        <xsl:param name="tracking_var_1"/>
        <xsl:param name="tracking_var_2"/>
        <xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<audr:execute>
			<aud:request-wrapper>
				<aud:Auditing>
					<aud:AuditingType>
						<xsl:value-of select="'Error'"/>
					</aud:AuditingType>
					<aud:FlowInstanceID>
						<xsl:value-of select="ic:getFlowId()"/>
					</aud:FlowInstanceID>
					<aud:TrackingID>
						<xsl:value-of select="/reqr:execute/req:request-wrapper/req:EmployeesBatch/req:BatchID"/>
					</aud:TrackingID>
					<aud:ReferenceID>
						<xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
					</aud:ReferenceID>
					<aud:InterfaceName>
						<xsl:value-of select="$self/med:metadata/med:integration/med:name"/>
					</aud:InterfaceName>
					<aud:Title>
						<xsl:value-of select="concat($self/med:metadata/med:integration/med:name, ' Error - ', ic:getFlowId())"/>
					</aud:Title>
					<aud:Details>
						<xsl:value-of select="concat ('ErrorCode:', $GlobalFaultObject/fault:fault/fault:errorCode, '; reason:', $GlobalFaultObject/fault:fault/fault:reason, '; details:', $GlobalFaultObject/fault:fault/fault:details )"/>
					</aud:Details>
					<aud:Payload>
						<xsl:value-of select="oraext:get-content-as-string(/reqr:execute/req:request-wrapper/req:CollectiveViewOutbound)"/>
					</aud:Payload>
					<aud:AuditingID>
						<xsl:value-of select="oraext:generate-guid ()"/>
					</aud:AuditingID>
				</aud:Auditing>
			</aud:request-wrapper>
		</audr:execute>
	</xsl:template>
</xsl:stylesheet>