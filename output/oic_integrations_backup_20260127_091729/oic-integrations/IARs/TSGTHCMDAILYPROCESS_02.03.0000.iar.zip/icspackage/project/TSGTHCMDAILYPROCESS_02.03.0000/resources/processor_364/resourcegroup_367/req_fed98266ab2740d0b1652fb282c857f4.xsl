<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet xmlns:rptw="http://xmlns.oracle.com/types/RunChecklistReport/1632595121543/OutboundSOAPRequestDocument" xmlns:report="http://xmlns.oracle.com/oxp/service/PublicReportService" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:srcr="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger_REQUEST/types" xmlns:src="http://xmlns.oracle.com/cloud/adapter/REST/OutboundTrigger/types" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" version="2.0" xml:id="id_1" exclude-result-prefixes=" oraext plnk xsd xp20 ora nssrcmpr oracle-xsl-mapper nssrcdfl xsi fn xsl ns1 ignore01" ignore01:ignorexmlids="true" xmlns:xml="http://www.w3.org/XML/1998/namespace">

        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_8/resourcegroup_9/ICSSchedule_1.xsd"/>
                          <oracle-xsl-mapper:rootElement name="schedule" namespace="http://www.oracle.com/2014/03/ics/schedule"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_319/inbound_320/resourcegroup_321/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_29/resourcegroup_30/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_348/inbound_349/resourcegroup_350/RunExtractReport_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/RunExtractReport/1680484525790/OutboundSOAPRequestDocument"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="LastRunTime"/>
	<xsl:param name="Now"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<rptw:OutboundSOAPRequestDocument>
			<rptw:Body>
				<report:runReport>
					<report:reportRequest>
						<report:parameterNameValues>
							<report:item>
								<report:name>p_flow_names</report:name>
								<report:values>
									<report:item>
										<xsl:choose>
											<xsl:when test="count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract']) > 0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract'])=0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract'])=0">
												<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract']/cfg:Value"/>
											</xsl:when>
											<xsl:when test="count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract']) > 0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract'])>0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract'])=0">
												<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract']/cfg:Value,',',$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract']/cfg:Value)"/>
											</xsl:when>
											<xsl:when test="count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract']) > 0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract'])=0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract'])>0">
												<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract']/cfg:Value,',',$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract']/cfg:Value)"/>
											</xsl:when>
											<xsl:when test="count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract'])=0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract'])>0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract'])>0">
												<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract']/cfg:Value,',',$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract']/cfg:Value)"/>
											</xsl:when>
											<xsl:when test="count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract'])>0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract'])>0 and count($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract'])>0">
												<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeesExtract']/cfg:Value,',',$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeTerminationExtract']/cfg:Value,',',$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract']/cfg:Value)"/>
											</xsl:when>
										</xsl:choose>
									</report:item>
								</report:values>
							</report:item>
						</report:parameterNameValues>
						<report:reportAbsolutePath>
							<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='ExtractlistReport']/cfg:Value"/>
						</report:reportAbsolutePath>
					    <report:sizeOfDataChunkDownload>-1</report:sizeOfDataChunkDownload>
					</report:reportRequest>
				</report:runReport>
			</rptw:Body>
		</rptw:OutboundSOAPRequestDocument>
	</xsl:template>
</xsl:stylesheet>