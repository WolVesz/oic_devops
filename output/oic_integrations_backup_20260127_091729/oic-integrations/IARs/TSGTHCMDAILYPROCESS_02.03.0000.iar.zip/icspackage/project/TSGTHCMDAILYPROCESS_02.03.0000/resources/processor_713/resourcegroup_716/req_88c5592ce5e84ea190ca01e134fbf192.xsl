<?xml version = '1.0' encoding = 'UTF-8'?>
<xsl:stylesheet version="2.0" xmlns:sbm="http://xmlns.oracle.com/cloud/adapter/hcm/ScheduleCollectiveView_REQUEST/types" xmlns:fls="http://xmlns.oracle.com/apps/hcm/processFlows/core/flowControllerService/" xmlns:cfg="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types" xmlns:jsl="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.JsExecutor_xpath282459557" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:orafault="http://xmlns.oracle.com/oracleas/schema/oracle-fault-11_0" xmlns:oraext="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.ExtFunc" xmlns:xp20="http://www.oracle.com/XSL/Transform/java/oracle.tip.pc.services.functions.Xpath20" xmlns:ora="http://schemas.oracle.com/xpath/extension" xmlns:oracle-xsl-mapper="http://www.oracle.com/xsl/mapper/schemas" xmlns:tns="http://xmlns.oracle.com/apps/hcm/processFlows/core/flowActionsService/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:fn="http://www.w3.org/2005/xpath-functions" xmlns:xsl="http://www.w3.org/1999/XSL/Transform" xmlns:ignore01="http://www.oracle.com/XSL/Transform/java" exclude-result-prefixes=" nssrcmpr oraext xsd xp20 ora oracle-xsl-mapper xsi fn nsmpr0 xsl ignore01" ignore01:ignorexmlids="true">


        <oracle-xsl-mapper:schema>
              <!--SPECIFICATION OF MAP SOURCES AND TARGETS, DO NOT MODIFY.-->
              <oracle-xsl-mapper:mapSources>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_8/resourcegroup_9/ICSSchedule_1.xsd"/>
                          <oracle-xsl-mapper:rootElement name="schedule" namespace="http://www.oracle.com/2014/03/ics/schedule"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_319/inbound_320/resourcegroup_321/GetConfigs_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="response-wrapper" namespace="http://xmlns.oracle.com/cloud/adapter/REST/GetConfigs/types"/>
                          <oracle-xsl-mapper:param name="Configs"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_404/resourcegroup_405/ReadFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="ReadResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/ReadFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="ReadFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_348/inbound_349/resourcegroup_350/RunExtractReport_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="runReportResponse" namespace="http://xmlns.oracle.com/oxp/service/PublicReportService"/>
                          <oracle-xsl-mapper:param name="RunExtractReport"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_348/inbound_349/resourcegroup_350/RunExtractReport_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="OutboundSOAPRequestDocument" namespace="http://xmlns.oracle.com/types/RunExtractReport/1680484525790/OutboundSOAPRequestDocument"/>
                          <oracle-xsl-mapper:param name="RunExtractReport_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_385/resourcegroup_386/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="WriteResponse" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="WSDL">
                          <oracle-xsl-mapper:schema location="../../processor_385/resourcegroup_386/WriteFile_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="Write" namespace="http://xmlns.oracle.com/cloud/adapter/stagefile/WriteFile_REQUEST/types"/>
                          <oracle-xsl-mapper:param name="WriteFile_REQUEST"/>
                    </oracle-xsl-mapper:source>
                    <oracle-xsl-mapper:source type="XSD">
                          <oracle-xsl-mapper:schema location="../../processor_29/resourcegroup_30/ICSIntegrationMetadata.xsd"/>
                          <oracle-xsl-mapper:rootElement name="metadata" namespace="http://www.oracle.com/2014/03/ic/integration/metadata"/>
                          <oracle-xsl-mapper:param name="self"/>
                    </oracle-xsl-mapper:source>
              </oracle-xsl-mapper:mapSources>
              <oracle-xsl-mapper:mapTargets>
                    <oracle-xsl-mapper:target type="WSDL">
                          <oracle-xsl-mapper:schema location="../../application_675/inbound_676/resourcegroup_705/ScheduleCollectiveView_REQUEST.wsdl"/>
                          <oracle-xsl-mapper:rootElement name="submitFlow" namespace="http://xmlns.oracle.com/cloud/adapter/hcm/ScheduleCollectiveView_REQUEST/types"/>
                    </oracle-xsl-mapper:target>
              </oracle-xsl-mapper:mapTargets>
        </oracle-xsl-mapper:schema>
		
	<xsl:param name="Configs"/>
	<xsl:param name="LastRunTime"/>
	<xsl:param name="Now"/>
	<xsl:param name="ReadFile"/>
	<xsl:param name="RunExtractReport"/>
	<xsl:param name="RunExtractReport_REQUEST"/>
	<xsl:param name="WriteFile"/>
	<xsl:param name="WriteFile_REQUEST"/>
	<xsl:param name="self"/>
	<xsl:param name="tracking_var_1"/>
	<xsl:param name="tracking_var_2"/>
	<xsl:param name="tracking_var_3"/>
	
	<xsl:template match="/">
		<sbm:submitFlow>
			<sbm:flowName>
				<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract']/cfg:Value"/>
			</sbm:flowName>
			<sbm:flowInstanceName>
				<xsl:value-of select="concat($Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='EmployeeCollectiveViewExtract']/cfg:Value,xp20:format-dateTime(string($Now), '[Y0001][M01][D01][H01][m01][s01]'))"/>
			</sbm:flowInstanceName>
			<sbm:legislativeDataGroupName>US Legislative Data Group</sbm:legislativeDataGroupName>
			<sbm:scheduleFormulaTypeName>Flow Schedule</sbm:scheduleFormulaTypeName>
			<sbm:scheduleFormulaName>
				<xsl:value-of select="$Configs/cfg:response-wrapper/cfg:Configs[cfg:Key='DailyFormula']/cfg:Value"/>
			</sbm:scheduleFormulaName>
			<sbm:scheduledDate>
				<xsl:value-of select="concat(xp20:format-dateTime((xsd:dateTime($Now) + xsd:dayTimeDuration('P1D')), '[Y0001]-[M01]-[D01]'),'T00:15:00.000Z')"/>
			</sbm:scheduledDate>
			<sbm:recurringFlag>
				<xsl:value-of select="'true'"/>
			</sbm:recurringFlag>
			<sbm:endDate>
				<xsl:value-of select="concat(jsl:GetNextMonth(),'-02T00:00:00.000Z')"/>
			</sbm:endDate>
		</sbm:submitFlow>
	</xsl:template>
</xsl:stylesheet>